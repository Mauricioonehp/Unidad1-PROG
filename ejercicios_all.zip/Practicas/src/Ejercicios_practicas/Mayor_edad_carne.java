package Ejercicios_practicas;

import javax.swing.JOptionPane;

//. Mayor de edad y carné. Pide una edad y si tiene carné (S o N). Muestra “Puede conducir” solo si tiene 18 o más años y ha respondido S (ignorando mayúsculas). Si la edad es negativa, avisa y reinicia.
//
//Recuerda:
//
//Usa JOptionPane para pedir los datos y para mostrar cada resultado.
//La edad es un int y el carné es un String.
//Para comparar el carné ignorando mayúsculas, usa equalsIgnoreCase("S"), nunca ==.
//“Y” entre dos condiciones se escribe con &&.
//Primero valida la edad: si es negativa, avisa y reinicia con main(null); y return; (o mete lo demás dentro del else).
//Piensa qué pasa si tiene 18 años pero responde N, o si responde S pero tiene 17. En ninguno de los dos casos puede conducir.
public class Mayor_edad_carne {
	public static void main(String[] args) {
		
		int edad = Integer.parseInt(JOptionPane.showInputDialog("ingresa tu edad "));

		String carne = JOptionPane.showInputDialog("¿Tienes carné? (S/N)");

		if (edad <= 0 || edad > 100) {
			JOptionPane.showMessageDialog(null, "INGRESA DATOS VALIDOS ");
			main(null);
		}
		else {

			if (edad >= 18 && carne.equalsIgnoreCase("S")) {
				JOptionPane.showMessageDialog(null, "Usted pude manejar ");
			} 
			else {
					JOptionPane.showMessageDialog(null, "no puedes conducir ");
				}
			}

		}

	}


