package Ejercicios_practicas;
//6. Contraseña segura. Pide una contraseña con JOptionPane. Es segura solo si tiene al menos 8 caracteres y no es igual a la palabra

import javax.swing.JOptionPane;

///
//
//Recuerda:
//
//showInputDialog ya devuelve un String, así que no hace falta convertir nada.
//Para contar los caracteres: length(). Por ejemplo, "hola".length() da 4.
//Para comparar ignorando mayúsculas: equalsIgnoreCase("password"). Nunca uses == con Strings.
//Para “no es igual” pon un ! delante: !clave.equalsIgnoreCase("password").
//“Y” entre las dos condiciones se escribe con &&.
//Controlar el null significa comprobar clave == null antes de llamar a length() o a equalsIgnoreCase. Si el usuario pulsa Cancelar, clave es null y llamar a un método sobre él da error. Si es null, avisa y reinicia con main(null);, dejando el resto en el else.
//Piensa qué ocurre con una contraseña de 8 o más caracteres que sea “PASSWORD” en mayúsculas: tiene longitud suficiente, pero igualmente no es segura.
public class Contraseñas {

	public static void main(String[] args) {
		
		String clave = JOptionPane.showInputDialog("iNGRESA CONTRASEÑA ");
		
		 // Primero el null, antes de usar length() o equalsIgnoreCase()
        if (clave == null) {
            JOptionPane.showMessageDialog(null, "No has introducido ninguna contraseña");
            main(null);   // Reinicia la aplicación

        }
        else {

            if (clave.length() >= 8 && !clave.equalsIgnoreCase("password")) {
                JOptionPane.showMessageDialog(null, "La contraseña es segura");
            } else {
                JOptionPane.showMessageDialog(null, "La contraseña NO es segura");
            }
        }
//		
//        length() cuenta los caracteres: "hola".length() da 4.
//        equalsIgnoreCase compara ignorando mayúsculas, así que PASSWORD, Password y password cuentan como la misma palabra.
//        ! da la vuelta al resultado: queremos que no sea igual.
//
//        Para que sea segura hacen falta las dos a la vez, y eso se escribe con &&:
		
	}

}
