package Ejercicios_practicas;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//3. Descuento por cantidad. Pide el precio de un producto y las unidades que se compran. Si compra 10 o más, aplica un 15 % de descuento.
//Si compra de 5 a 9, un 8 %. Si compra menos de 5, no hay descuento. Muestra el total con DecimalFormat.
public class Descuento_por_cantidad {

	public static void main(String[] args) {
		
		Double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el precio del producto"));
		
		int unidades = Integer.parseInt(JOptionPane.showInputDialog("INGREA LAS UNIDADES DEL PRODCUTO"));
		
			

        // Total sin descuento: precio de una unidad por las unidades
        double total = precio * unidades;

        // 2) Si hay descuento, se le resta al total
        if (unidades >= 10) {
            total -= total * 0.15;   // quita el 15 %
        } else if (unidades >= 5) {
            total -= total * 0.08;   // quita el 8 %
        }
        // De mayor a menor: en cada if solo hace falta el límite inferior
//        if (unidades >= 10) {
//            total *= (1 - 15 / 100.0);   // 15 % de descuento
//        } else if (unidades >= 5) {
//            total *= (1 - 8 / 100.0);    // 8 % de descuento
//        }
//        // Menos de 5 unidades: no se toca el total

        DecimalFormat df = new DecimalFormat("0.00");

        JOptionPane.showMessageDialog(null, "El total a pagar es " + df.format(total));
    }
}


//// otra manera :
//public static void main(String[] args) {
//
//    double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el precio del producto"));
//    int unidades = Integer.parseInt(JOptionPane.showInputDialog("Ingresa las unidades"));
//
//    // Total sin descuento
//    double total = precio * unidades;
//
//    DecimalFormat df = new DecimalFormat("0.00");
//
//    if (unidades >= 10) {
//        total -= total * 0.15;   // quita el 15 %
//        JOptionPane.showMessageDialog(null, "Descuento del 15 %\nTotal a pagar: " + df.format(total));
//
//    } else if (unidades >= 5) {
//        total -= total * 0.08;   // quita el 8 %
//        JOptionPane.showMessageDialog(null, "Descuento del 8 %\nTotal a pagar: " + df.format(total));
//
//    } else {
//        // Menos de 5 unidades: el total no cambia
//        JOptionPane.showMessageDialog(null, "No hay descuento\nTotal a pagar: " + df.format(total));
//    }
//}
//}


