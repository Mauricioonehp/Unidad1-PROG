package Ejercicios_practicas;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

/*
 * 10. Presión arterial.
 *     Pedir la presión sistólica y la diastólica (enteros) y clasificar:
 *       Óptima: sistólica < 120 Y diastólica < 80
 *       Normal: sistólica de 120 a 129 Y diastólica < 85
 *       Alta:   cualquier otro caso
 *     Si algún valor es <= 0, avisar y reiniciar.
 *     Guardar el resultado en presion.html (tabla de dos columnas) y abrirlo con Desktop.
 */
public class Presion_arterial {

	// throws IOException: necesario por FileWriter y Desktop (sustituye al try/catch)
    public static void main(String[] args) throws IOException {

        // ===================== 1) PEDIR LOS DATOS =====================

        // Son enteros, por eso Integer.parseInt
        int sistolica = Integer.parseInt(JOptionPane.showInputDialog("Ingresa la presión sistólica"));
        int diastolica = Integer.parseInt(JOptionPane.showInputDialog("Ingresa la presión diastólica"));

        // ===================== 2) VALIDAR =====================

        // Si alguna es 0 o negativa: avisa, reinicia y sale
        if (sistolica <= 0 || diastolica <= 0) {
            JOptionPane.showMessageDialog(null, "Los valores deben ser mayores que 0");
            main(null);   // Reinicia la aplicación
               // Evita seguir con datos incorrectos al terminar la repetición
        }

        // ===================== 3) CLASIFICAR =====================

        // Guardamos el resultado en un String para escribirlo una sola vez en el HTML
        String clasificacion;

        if (sistolica < 120 && diastolica < 80) {
            clasificacion = "Óptima";

        } else if (sistolica >= 120 && sistolica <= 129 && diastolica < 85) {
            // "de 120 a 129" necesita DOS comparaciones unidas con &&
            clasificacion = "Normal";

        } else {
            // Cualquier otro caso
            clasificacion = "Alta";
        }

        // ===================== 4) ESCRIBIR EL HTML =====================

        // PrintWriter permite usar println (salta de línea solo). Ruta relativa: se
        // crea en la carpeta del proyecto. "false" = crea / sobrescribe el archivo.
        PrintWriter pw = new PrintWriter(new FileWriter("presion.html", false));

        pw.println("<html><head><meta charset='UTF-8'><title>Presión arterial</title></head>");
        pw.println("<body><h1><center>Presión arterial</center></h1>");

        // Tabla de dos columnas: una fila de encabezados (th) y una de datos (td)
        pw.println("<center><table border='1' style='text-align: center'>");
        pw.println("<tr><th>DATOS</th><th>RESULTADO</th></tr>");
        pw.println("<tr><td>Sistólica: " + sistolica + " / Diastólica: " + diastolica
                + "</td><td>" + clasificacion + "</td></tr>");
        pw.println("</table></center></body></html>");

        pw.flush();   // vuelca lo pendiente al archivo
        pw.close();   // cierra el archivo (si no, puede quedar vacío)

        // ===================== 5) ABRIRLO =====================

        // Se abre con el programa asociado a .html (el navegador).
        // El nombre debe ser el MISMO que el del FileWriter.
        Desktop.getDesktop().open(new File("presion.html"));
    }
}