package Ejercicios_practicas;

import javax.swing.JOptionPane;

//Propina. Pide el importe de una cuenta (decimal) y el porcentaje de propina. 
//Calcula la propina con *= y muestra el total a pagar redondeado al entero más próximo.
public class Calcular_Propina {

	public static void main(String[] args) {
		

		double importe = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingresa importe total"));
		double propina = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingresa	 el porcentaje de propina"));
		
		
		importe*=(1+propina/100);
		
		JOptionPane.showMessageDialog(null,"total a pagar es "+Math.round(importe) );
		
	}

}
