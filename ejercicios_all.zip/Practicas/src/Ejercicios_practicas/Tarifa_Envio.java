package Ejercicios_practicas;

import javax.swing.JOptionPane;

//
//Tarifa de envío. Un método double calcularEnvio(double peso) devuelve el coste de un envío: hasta 1 kg cuesta 5 €, de más de 1 hasta 5 kg cuesta 9 €,
//y por encima de 5 kg cuesta 15 €. Si el peso es 0 o negativo, debe avisar y reiniciar. El main pide el peso y muestra el coste.
//
//Recuerda:
//
//Esta vez el método devuelve un valor (double) con return, y el main es quien lo muestra.
//Para el peso inválido, el error es peso <= 0, porque el 0 tampoco vale.
//Es una escala de tres tramos. Ordénala de menor a mayor: primero peso <= 1, luego peso <= 5, y el resto en el else.
//Si el método reinicia con main(null);, necesita un return después (por ejemplo return 0.0;), porque un método double debe devolver algo en todos los caminos.
public class Tarifa_Envio {
	
	// Tarifa de envío: hasta 1 kg 5 €, hasta 5 kg 9 €, más de 5 kg 15 €.

    // Método que DEVUELVE el coste según el peso

	public static double envio(double peso) {
        // Peso 0 o negativo: avisa y reinicia

		if (peso<=0) {
			
			JOptionPane.showMessageDialog(null, "El peso debe ser mayor a 0");
			main(null);
		}
		
			if (peso<=1) {
			return 5;
		}
			else if (peso<=5) {
				return 9;
			}
			else {
				return 15;
			}
		
		
		
	}

	public static void main(String[] args) {
		
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el peso "));
		
		
		double costeo =envio(peso);
		JOptionPane.showMessageDialog(null, "el coste de envio total es "+costeo+" euros");
		
		
	}

}
