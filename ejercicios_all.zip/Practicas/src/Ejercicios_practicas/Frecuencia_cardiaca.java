package Ejercicios_practicas;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

/*
 * 12. Frecuencia cardíaca máxima.
 *     Hombres: 220 - edad | Mujeres: 226 - edad
 *     Se piden sexo, edad (solo de 15 a 90 años) y las pulsaciones actuales.
 *     Se calcula el porcentaje de las pulsaciones sobre la máxima y se muestra la zona:
 *       menos de 50 %      -> Reposo
 *       50 % a menos de 70 -> Ligera
 *       70 % a menos de 85 -> Intensa
 *       85 % o más         -> Máxima
 */
public class Frecuencia_cardiaca {

    public static void main(String[] args) {

        // ===================== 1) PEDIR LOS DATOS =====================

        String sexo = JOptionPane.showInputDialog("Ingresa tu sexo (H = hombre, M = mujer)");
        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tu edad"));
        int pulsaciones = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tus pulsaciones actuales"));

        // ===================== 2) VALIDAR =====================

        // Error si: la edad no está entre 15 y 90, o el sexo no es ni H ni M.
        // !( A || B ) significa "no es ni A ni B".
        if (edad < 15 || edad > 90 || !(sexo.equalsIgnoreCase("H") || sexo.equalsIgnoreCase("M"))) {
            JOptionPane.showMessageDialog(null, "Datos no válidos (edad de 15 a 90 y sexo H o M)");
            main(null);   // Reinicia la aplicación
              
        }

        // ===================== 3) FRECUENCIA CARDÍACA MÁXIMA =====================

        int maxima;

        if (sexo.equalsIgnoreCase("H")) {
            maxima = 220 - edad;   // hombres
        } else {
            maxima = 226 - edad;   // mujeres
        }

        // ===================== 4) PORCENTAJE =====================

        // Se multiplica por 100.0 (decimal) para que la división conserve decimales.
        // Con enteros, 80 * 100 / 190 daría 42 (sin decimales).
        double porcentaje = pulsaciones * 100.0 / maxima;

        // "0.00" = siempre dos decimales
        DecimalFormat df = new DecimalFormat("0.00");

        // ===================== 5) ZONA (de menor a mayor) =====================

        String mensaje = "Frecuencia máxima: " + maxima + " ppm"
                + "\nPorcentaje: " + df.format(porcentaje) + " %\n";

        if (porcentaje < 50) {
            JOptionPane.showMessageDialog(null, mensaje + "Zona de REPOSO");
        } else if (porcentaje < 70) {
            JOptionPane.showMessageDialog(null, mensaje + "Zona LIGERA");
        } else if (porcentaje < 85) {
            JOptionPane.showMessageDialog(null, mensaje + "Zona INTENSA");
        } else {
            JOptionPane.showMessageDialog(null, mensaje + "Zona MÁXIMA");
        }
    }
}