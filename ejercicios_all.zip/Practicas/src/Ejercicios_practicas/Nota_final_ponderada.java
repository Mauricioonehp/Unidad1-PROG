package Ejercicios_practicas;

import javax.swing.JOptionPane;

//8. Nota final ponderada. Pide la nota de un examen (50 % de la nota final), la de un trabajo (30 %) y la de actitud (20 %). Las tres van de 0 a 10; si alguna no lo está, avisa y reinicia. 
//Muestra la nota final redondeada al entero más próximo y la calificación: Suspenso, Aprobado, Notable o Sobresaliente.
//Recuerda:
//
//Las notas son decimales, así que usa double con Double.parseDouble.
//Valida las tres con ||: el error es que alguna sea < 0 o > 10.
//La nota final es examen * 0.50 + trabajo * 0.30 + actitud * 0.20.
//Redondea con (int) Math.round(...), con todo el cálculo dentro del round.
//Escala de calificaciones, como en el ejercicio de las dos notas de antes: Sobresaliente de 9 a 10,
//Notable de 7 a 8, Aprobado de 5 a 6 y Suspenso por debajo de 5. Ordénala de mayor a menor y usa solo el límite inferior en cada if.
//Usa la nota ya redondeada (int) para clasificar.
public class Nota_final_ponderada {

	public static void main(String[] args) {
		
		   // ----- PEDIR LAS TRES NOTAS -----
        double examen = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la nota del examen"));
        double trabajo = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la nota del trabajo"));
        double actitud = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la nota de actitud"));

        // ----- VALIDAR: las tres deben estar entre 0 y 10 -----
        if (examen < 0 || examen > 10 || trabajo < 0 || trabajo > 10 || actitud < 0 || actitud > 10) {
            JOptionPane.showMessageDialog(null, "Las notas deben estar entre 0 y 10");
            main(null);   // Reinicia la aplicación
        }

        // ----- NOTA FINAL: se pondera y luego se redondea (todo dentro del round) -----
        int notaFinal = (int) Math.round(examen * 0.50 + trabajo * 0.30 + actitud * 0.20);

        // ----- CALIFICACIÓN (de mayor a menor, solo el límite inferior) -----
        if (notaFinal >= 9) {
            JOptionPane.showMessageDialog(null, "Nota final: " + notaFinal + "\nSobresaliente");
        } else if (notaFinal >= 7) {
            JOptionPane.showMessageDialog(null, "Nota final: " + notaFinal + "\nNotable");
        } else if (notaFinal >= 5) {
            JOptionPane.showMessageDialog(null, "Nota final: " + notaFinal + "\nAprobado");
        } else {
            JOptionPane.showMessageDialog(null, "Nota final: " + notaFinal + "\nSuspenso");
        }
	}

}
