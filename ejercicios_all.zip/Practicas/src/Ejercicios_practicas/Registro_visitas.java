package Ejercicios_practicas;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

/*
 * 9. Registro de visitas.
 *    Pedir un nombre con JOptionPane y escribir en visitas.txt una línea
 *    "Visita de: " + nombre. El archivo debe AÑADIR al final sin borrar lo
 *    anterior, y después abrirse con Desktop.
 */
public class Registro_visitas {

    // throws IOException: avisa a Java de que FileWriter y Desktop pueden dar
    // error de archivo. Sustituye al try/catch.
    public static void main(String[] args) throws IOException {

        // ===================== 1) PEDIR EL NOMBRE =====================

        // showInputDialog ya devuelve un String, no hace falta convertir nada
        String nombre = JOptionPane.showInputDialog("Ingresa tu nombre");
        
        double edad = Double.parseDouble(JOptionPane.showInputDialog("INGRESA TU EDAD "));
        // ===================== 2) ESCRIBIR EN EL ARCHIVO =====================

        // new FileWriter("visitas.txt", true):
        //   - Si el archivo NO existe, lo crea.
        //   - El segundo parámetro "true" significa AÑADIR AL FINAL.
        //     Con "false" (o sin ponerlo) borraría lo que había antes.
        //   - Al no poner ruta, se guarda en la carpeta del proyecto de Eclipse.
        FileWriter fw = new FileWriter("visitas.txt", true); // false para sobrescribir 

        // \n al final para que cada visita quede en su propia línea
        fw.write("Visita de: " + nombre + "\n");
        fw.write("tu edad es  " + edad );
//        fw.write("Fecha: 26/10/2026\n");   para agregar mas texto hay que poner esto 
//        fw.write("----------\n");
        // flush() vuelca lo pendiente al archivo
        fw.flush();

        // close() cierra el archivo. Si se olvida, el archivo puede quedar vacío
        fw.close();

        // ===================== 3) ABRIRLO CON DESKTOP =====================

        // Desktop.getDesktop().open(...) abre el archivo con el programa que
        // Windows tiene asociado a ese tipo (.txt -> Bloc de notas).
        // new File("visitas.txt") representa el archivo; la ruta debe ser
        // la MISMA que la del FileWriter.
        Desktop.getDesktop().open(new File("visitas.txt"));
    }
}