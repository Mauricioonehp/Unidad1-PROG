package Ejercicios_practicas;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//Rectángulo. Crea un método void llamado mostrarRectangulo que reciba la base y la altura (decimales)
//y muestre el área y el perímetro con dos decimales. Debe controlar que ambos sean mayores que 0 o reiniciar la aplicación.
public class Rectangulo {

	public static void mostrarRectangulo(double altura , double base) {
		double area = base*altura;
		
		DecimalFormat df = new DecimalFormat("0.00");
		
		double perimeto = 	2*(base+altura);
		// Ambos deben ser mayores que 0
		if (base<=0 || altura<=0) {
			JOptionPane.showMessageDialog(null, "error ingresa datos validos ");
			main(null);// Reinicia la aplicación
		}
		else {
			JOptionPane.showMessageDialog( null,"el area el rectaugndo el "+(df.format(area))+"y el perimetro es "+(df.format(perimeto)));
		}
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
	

		double base = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la base en decimal "));
		
		double altura = Double.parseDouble(JOptionPane.showInputDialog("ingresa la altura en decimal"));
		
		mostrarRectangulo(altura, base);
		
		
	}

}
