package Ejercicios_practicas;

import javax.swing.JOptionPane;

//
//5. Capicúa de tres cifras. Pide un número entero de tres cifras (de 100 a 999) y di si es capicúa (por ejemplo 121 o 575). Si no tiene tres cifras, avisa y reinicia.
//
//Recuerda:
//
//Usa JOptionPane para pedir el número y para mostrar el resultado.
//Un número es capicúa si se lee igual al derecho y al revés. En tres cifras, basta con que la primera y la última sean iguales (la del medio da igual).
//Para sacar las cifras de un número entero:
//Última cifra: numero % 10. El % devuelve el resto de dividir entre 10. Con 574 da 4.
//Primera cifra: numero / 100. Con enteros, la división corta los decimales. Con 574 da 5.
//Para validar el rango: el error es numero < 100 || numero > 999. Si falla, avisa y reinicia con main(null); (con el resto dentro del else).
//El número es un int, así que usa Integer.parseInt.




public class Capicua {

	public static void main(String[] args) {
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("Ingresa un numero de 3 cifras "));
		
		
		// Validar: debe estar entre 100 y 999
        if (numero < 100 || numero > 999) {
            JOptionPane.showMessageDialog(null, "El número debe tener tres cifras");
            main(null);   // Reinicia la aplicación

        } else {
            int primera = numero / 100;   // 574 / 100 = 5
            int ultima = numero % 10;     // 574 % 10 = 4

            if (primera == ultima) {
                JOptionPane.showMessageDialog(null, numero + " es capicúa");
            } else {
                JOptionPane.showMessageDialog(null, numero + " no es capicúa");
            }
		
		
		
	}

	}
}

