package Proy;

import javax.swing.JOptionPane;

public class par_impar {

	public static void main(String[] args) {
		// Muestra una ventana con un cuadro de texto.
        // Devuelve SIEMPRE un String (lo que el usuario escribio), o null si cancela.
        String texto = JOptionPane.showInputDialog("Ingresa un número para ver si es entero o no");
        // Convierte el String a int (conversión de tipo / parsing).
        // Lanza NumberFormatException si el texto no es un entero válido.
        int n =Integer.parseInt(texto);
     // Operador módulo (%): devuelve el resto de la división.
        // Si el resto de dividir entre 2 es 0, el número es par.
		if (n%2==0) {
			JOptionPane.showMessageDialog(null, n+"Es par");
			 // Muestra una ventana de mensaje.
            // null = sin ventana padre (se centra en pantalla).
            // n + " es par" = concatenación: el int se convierte a texto automáticamente.
		}
		else {
            // Si el resto no es 0, es impar.

			JOptionPane.showMessageDialog(null, n+" No es par");
		}
		
	}

}
