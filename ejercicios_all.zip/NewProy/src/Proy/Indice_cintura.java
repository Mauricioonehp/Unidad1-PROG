package Proy;

import javax.swing.JOptionPane;

public class Indice_cintura {
	// Metodo static para llamarlo desde el main sin crear un objeto
	// Recibe 3 parametros y devuelve un double (el ICC)
	
	
	public static double ICC(double cintura, double cadera,String sexo) {
		// Calculo del ICC: cintura / cadera
		// Es double porque tiene decimales y no se redondea
		double ICC= cintura/cadera;
		// Decision segun el sexo
		// equalsIgnoreCase compara el texto sin importar mayusculas
		// No se usa == para comparar Strings
		
		if (sexo.equalsIgnoreCase("H")) {
			
			// Hombres riesgo alto: mayor que 0.95
			
			if (0.95<ICC) {
				JOptionPane.showMessageDialog(null, "RIESGO ALTO DE PROBLEMAS CARDIACOS");
			}
			// Hombres riesgo moderado: de 0.90 a 0.95
			// && significa que se cumplen las dos condiciones a la vez
			// No se usa == con double porque la division casi nunca es exacta
			else if (ICC >= 0.90 && ICC <= 0.95) {
				JOptionPane.showMessageDialog(null, "Riesgo moderado ");
				// Hombres riesgo bajo: lo que queda (menor que 0.90)

			}
			
			// Hombres riesgo bajo: lo que queda (menor que 0.90)
			else {
				JOptionPane.showMessageDialog(null, "Riesgo bajo");
			}
			
			// Mujeres: llega aqui si el sexo no era H
			// Riesgo alto: mayor que 0.85
		}
		else if (0.85<ICC) {
			JOptionPane.showMessageDialog(null, "RIESGO ALTO DE PROBLEMAS CARDIACOS MUJER");
		}
		// Mujeres riesgo moderado: de 0.80 a 0.85

		else if (ICC >= 0.80 && ICC <= 0.85) {
			JOptionPane.showMessageDialog(null, "Riesgo moderado mujer ");
			// Mujeres riesgo bajo: lo que queda (menor que 0.80)
		}
		else {
			JOptionPane.showMessageDialog(null, "Riesgo bajo mujer ");
		}
		// Devuelve el ICC a quien llamo al metodo

		
		return ICC;
	}
	public static void main(String[] args) {
		// showInputDialog devuelve String y se convierte con parseDouble
		// Si cancela o escribe letras da error y no se controla porque el enunciado no lo pide
		
		double cintura = Double.parseDouble(JOptionPane.showInputDialog("ingresa cintura en cm :"));
		double cadera = Double.parseDouble(JOptionPane.showInputDialog("ingresa cadera en cm"));
		// El sexo se queda como String
		String sexo = JOptionPane.showInputDialog("Sexo (H o M):");
		
		// Llamada al metodo: los argumentos se copian a los parametros

		ICC(cintura, cadera, sexo);
	}

}
