package Proy;

import javax.swing.JOptionPane;

public class indice_cintura_talla {
//	.- Calcular el Índice Cintura-Talla (ICT) pidiendo los datos al usuario. Sabiendo que la fórmula a aplicar es ICT = Perímetro de cintura (cm) / Altura (cm). 
//	Presenta los siguientes rangos,
//	Valores <= 0,5 son considerados normales
//	Valores > 0,5 son considerados con propensión a las enfermedades cardiovasculares.

	
	
	
	
	public static double ICTE(double cintura,double altura) {
		
		Double ICT =cintura/altura;
		
		
		if (ICT<=0.5) {
			JOptionPane.showMessageDialog(null,"Esta considerado normales");
		}
		else {
			JOptionPane.showMessageDialog(null, "CONSIDERADO CON PROPENSIONES ENFERMEDADES CARDIOVASCULARES");
		}
		
		
		
		
		return ICT;
		
		
		
	}
	
	public static void main(String[] args) {

		double cintura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa cintura en cm"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa altura en cm"));
		
		
		
	
		ICTE(cintura, altura);
		
	}

}
