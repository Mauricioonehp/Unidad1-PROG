package Proy;

public class CalcularTobillo {

	
	
	
	public static void main(String[] args) {

		
		
		
		
		
	}

}
