package Proy;

import javax.swing.JOptionPane;

public class Imc_pesos {

	public static void main(String[] args) {

		// se parsea pero es showImputDialog y no lleva NULL
		
		// ENTRADA: showInputDialog devuelve un String, por eso se convierte
		// a double con parseDouble (el peso y la altura pueden tener decimales).
		// No se controla null (Cancelar) porque el enunciado no lo pide.
		// OJO: la altura se escribe con punto (1.75), no con com
		double peso = Double.parseDouble(JOptionPane.showInputDialog("ingresa tu peso"));
		// CÁLCULO: IMC exacto = peso / altura al cuadrado.
		// Los paréntesis son obligatorios: sin ellos, Java haría (peso / altura) * altura.
		// MEJORA DE NOMBRE: en Java las variables van en camelCase (imcExacto, no IMCE).
		double altura =Double.parseDouble(JOptionPane.showInputDialog("Ingresa tu altura"));

        // Math.pow(base, exponente) también valdría: Math.pow(altura, 2).
		
		// CÁLCULO: IMC exacto = peso / altura al cuadrado.
		// Los paréntesis son obligatorios: sin ellos, Java haría (peso / altura) * altura.
		// MEJORA DE NOMBRE: en Java las variables van en camelCase (imcExacto, no IMCE).
		double IMCE = peso/(altura*altura);
		// REDONDEO: Math.round(double) devuelve un long, por eso
		// hace falta el cast (int) para guardarlo en una variable int.
		// Se redondea ANTES de comparar, así que 15.57 pasa a ser 16.
		//math.round redondea el numero decial a un entero mas proximo 
		int IMC = (int) Math.round(IMCE);
		// CONDICIONES: van de menor a mayor, así cada else if ya "sabe"
		// que el valor supera el tramo anterior y no hacen falta && .
		// Los extremos (16, 25, 30, 40) pasan al tramo superior.
		
		
		if (IMC <16 ) {
			JOptionPane.showMessageDialog(null, "INFRAPESO IMC: "+IMC) ;
		}
		else if (IMC< 25 ) {
			JOptionPane.showMessageDialog(null, "Peso ideal: "+IMC);
		}
		else if (IMC<30) {
			JOptionPane.showMessageDialog(null, "Sobrepeso: "+IMC);
		}
		else if (IMC<40 ) {
			JOptionPane.showMessageDialog(null, "Obeso:  "+IMC);
		}
		else {
			JOptionPane.showMessageDialog(null, "PELIGRO OBESIDAD MORBIDA");
		}
		
	}

}
