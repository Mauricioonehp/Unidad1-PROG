package Proy;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

public class icm_h_m {

	
	// MÉTODO 1: calcula el ICT. Recibe dos números y devuelve un número.

	
	public static double calcularIct(double cintura, double altura) {
		return cintura / altura;
	}
	
	// MÉTODO 2: calcula el % de grasa. La fórmula depende del sexo.

	public static double calcularGrasa(double ict, String sexo) {
		if (sexo.equalsIgnoreCase("H")) {
			return 106.5 * ict - 28.36;
		} else {
			return 89.73 * ict - 15.14;
		}
	}
	
	// MÉTODO 3: decide si el ICT es normal o no. Devuelve un texto.
	
	public static String clasificarIct(double ict) {
		if (ict <= 0.5) {
			return "NORMAL";
		} else {
			return "PROPENSION A ENFERMEDADES CARDIOVASCULARES";
		}
	}
	// MÉTODO 4: decide si el % de grasa es sano. Devuelve un texto.

	public static String clasificarGrasa(double grasa, String sexo, int edad) {
		double minimo;
		double maximo;

		if (sexo.equalsIgnoreCase("H")) {
			if (edad < 40) {
				minimo = 8;
				maximo = 19;
			} else if (edad < 60) {
				minimo = 11;
				maximo = 21;
			} else {
				minimo = 13;
				maximo = 24;
			}
		} else {
			if (edad < 40) {
				minimo = 21;
				maximo = 32;
			} else if (edad < 60) {
				minimo = 23;
				maximo = 33;
			} else {
				minimo = 24;
				maximo = 35;
			}
		}

		if (grasa >= minimo && grasa <= maximo) {
			return "%GC Sana";
		} else {
			return "%GC No Sana";
		}
	}
	public static void main(String[] args) {
		// 1. Pedir datos
		double cintura = Double.parseDouble(JOptionPane.showInputDialog("Cintura en cm:"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog("Altura en cm:"));
		String sexo = JOptionPane.showInputDialog("Sexo (H o M):");
		int edad = Integer.parseInt(JOptionPane.showInputDialog("Edad:"));
		
		
		// 2. Llamar a los métodos. Lo que devuelve uno se pasa al siguiente.
		double ict = calcularIct(cintura, altura);
		String claseIct = clasificarIct(ict);
		double grasa = calcularGrasa(ict, sexo);
		String claseGrasa = clasificarGrasa(grasa, sexo, edad);
		DecimalFormat formato = new DecimalFormat("0.00");

		formato.format(ict);
		

		// 3. Mostrar
		JOptionPane.showMessageDialog(null,
				"ICT: " + formato.format(ict) + claseIct + "\n"
				+ "%G: " + formato.format(grasa) + claseGrasa);
	}

}
