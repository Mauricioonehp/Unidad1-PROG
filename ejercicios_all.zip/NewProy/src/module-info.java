/**
 * 
 */
/**
 * 
 */
module NewProy {
	requires java.desktop;
}