package EjerciciosMetodos;

import java.text.DecimalFormat;
import java.util.Scanner;

/*
 * 10.- Índice Cintura-Talla (ICT) y porcentaje de grasa corporal (%G).
 *      ICT = perímetro de cintura (cm) / altura (cm)
 *      Hombres: %G = 106,5 * ICT - 28,36
 *      Mujeres: %G = 89,73 * ICT - 15,14
 *      Se muestra si el %G es sano o no sano según género y edad.
 *      Solo se controla que la edad esté entre 20 y 79 años.
 */
public class ICT {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // ----- PEDIR LOS DATOS -----
        System.out.println("Perímetro de la cintura (cm)");
        double cintura = sc.nextDouble();

        System.out.println("Altura (cm)");
        double altura = sc.nextDouble();

        System.out.println("Género (H = hombre, M = mujer)");
        char genero = sc.next().charAt(0);

        System.out.println("Edad");
        int edad = sc.nextInt();

        // ----- ÚNICO CONTROL: la edad debe estar entre 20 y 79 -----
        
        if (edad < 20 || edad > 79) {
            System.out.println("Edad no válida (debe estar entre 20 y 79). Vuelve a intentarlo");
            main(null);   // Reinicia la aplicación
        }

        sc.close();

        // ----- ICT -----
        double ict = cintura / altura;

        // ----- %G según el género, y límites de la tabla -----
        double grasa;
        double min;   // límite inferior del %GC sano
        double max;   // límite superior del %GC sano

        if (genero == 'H' || genero == 'h') {
            // HOMBRES
            grasa = 106.5 * ict - 28.36;

            if (edad <= 39) {          // 20-39
                min = 8;  max = 19;
            } else if (edad <= 59) {   // 40-59
                min = 11; max = 21;
            } else {                   // 60-79
                min = 13; max = 24;
            }

        } else {
            // MUJERES
            grasa = 89.73 * ict - 15.14;

            if (edad <= 39) {          // 20-39
                min = 21; max = 32;
            } else if (edad <= 59) {   // 40-59
                min = 23; max = 33;
            } else {                   // 60-79
                min = 24; max = 35;
            }
        }

        // ----- MOSTRAR RESULTADOS (2 decimales) -----
        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("ICT: " + df.format(ict));
        System.out.println("Porcentaje de grasa corporal: " + df.format(grasa) + " %");

        if (grasa >= min && grasa <= max) {
            System.out.println("%GC Sana (intervalo sano: " + min + "-" + max + " %)");
        } else {
            System.out.println("%GC No Sana (intervalo sano: " + min + "-" + max + " %)");
        }
    }
}