package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//2.- Crear un programa que calcule el área de una circunferencia aplicando la fórmula A = PI * r2
//. Usaremos
//Math.PI y pediremos solamente el radio en el main, mientras que el cálculo y visualización del resultado se hará
//en un método void que controlará que el radio no sea menor de 0.0 o reiniciará la aplicación. Obtener siempre
//dos decimales
public class Circunferencia {

	
	 // Método void: controla, calcula y muestra (no devuelve nada)
    public static void area(double radio) {

        // El radio no puede ser menor de 0.0
        if (radio < 0.0) {
            JOptionPane.showMessageDialog(null, "El radio no puede ser negativo");
            main(null);   // Reinicia la aplicación: vuelve a pedir el radio

        } else {
            // Math.PI es la constante de PI; Math.pow(radio, 2) = radio al cuadrado
            double area = Math.PI * Math.pow(radio, 2);

            // "0.00" = siempre dos decimales
            DecimalFormat df = new DecimalFormat("0.00");

            JOptionPane.showMessageDialog(null, "El área de la circunferencia es: " + df.format(area));
        }
    }

    public static void main(String[] args) {

        // Solo se pide el radio, aquí en el main
        double radio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el radio"));

        // Llamamos al método pasándole el radio
        area(radio);
    }
}