package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

public class Grafico_botoenes {

	public static void main(String[] args) {

		double cintura = Double
				.parseDouble(JOptionPane.showInputDialog(null, "Inserte el perímetro de su cintura en cm"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Inserte su altura en cm"));
		int sexo = JOptionPane.showOptionDialog(null, "Seleccione su sexo", "Porcentaje Grasa Corporal",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
				new Object[] { "Hombre", "Mujer" }, null);
		int edades = JOptionPane.showOptionDialog(null, "Seleccione su edad", "Porcentaje Grasa Corporal",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
				new Object[] { "20-39", "40-59", "60-79" }, null);
		double ict = cintura / altura;
		double pgc_H = 106.5 * ict - 28.36;
		double pgc_M = 89.73 * ict - 15.14;
		DecimalFormat x = new DecimalFormat("#00.00");
		if (sexo == 0) { // Hombre
			if (edades == 0) { // 20-39
				if (pgc_H >= 8 && pgc_H <= 19) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_H));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_H));
				}
			} else if (edades == 1) { // 40-59
				if (pgc_H >= 11 && pgc_H <= 21) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_H));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_H));
				}
			} else if (edades == 2) { // 60-79
				if (pgc_H >= 13 && pgc_H <= 24) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_H));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_H));
				}
			}
		} else if (sexo == 1) { // Mujer
			if (edades == 0) { // 20-39
				if (pgc_M >= 21 && pgc_M <= 32) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_M));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_M));
				}
			} else if (edades == 1) { // 40-59
				if (pgc_M >= 23 && pgc_M <= 33) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_M));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_M));
				}
			} else if (edades == 2) { // 60-79
				if (pgc_M >= 24 && pgc_M <= 35) { // Sano
					JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc_M));
				} else { // No sano
					JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc_M));
				}
			}
		}
	}

}
