package EjerciciosMetodos;

import java.util.Scanner;

//6.- Realiza un programa que pida por consola la nota de un examen (decimal entre 1 y 10) y la actitud del
//alumno representada por un único carácter char ('S' para satisfactoria, cualquier otra letra para no satisfactoria).
//Si la nota no es correcta se deberá avisar al usuario y volver a lanzar la app. Crea un método propio
//evaluarAlumno que reciba la nota y el carácter de la actitud, y devuelva la nota como entero ajustada: si la
//actitud es 'S' (o 's'), la nota se incrementa en 1 punto utilizando el operador ++, y si la actitud es otra letras, la
//nota se decrementa en 1 punto utilizando el operador -- (sin superar el valor máximo de 10). Muestra si el
//alumno ha aprobado (nota final mayor o igual a 5) o no.
public class Examenes_notas {

	

	    // Método propio: recibe la nota y la actitud, y devuelve la nota final como entero
	    public static int evaluarAlumno(double nota, char actitud) {

	        // Pasamos la nota a entero (redondeando al más próximo)
	        int notaFinal = (int) Math.round(nota);

	        if (actitud == 'S' || actitud == 's') {
	            notaFinal++;              // Actitud satisfactoria: sube 1 punto

	            if (notaFinal > 10) {     // Sin superar el máximo de 10
	                notaFinal = 10;
	            }
	        } else {
	            notaFinal--;              // Actitud no satisfactoria: baja 1 punto
	        }

	        return notaFinal;
	    }

	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.println("Ingresa la nota del examen (entre 1 y 10)");
	        double nota = sc.nextDouble();

	        // Si la nota no es correcta, avisamos y reiniciamos la aplicación
	        if (nota < 1 || nota > 10) {
	            System.out.println("Nota no válida, vuelve a intentarlo");
	            main(null);
	        }

	        System.out.println("Ingresa la actitud (S = satisfactoria, otra letra = no satisfactoria)");
	        // next() lee una palabra y charAt(0) se queda con su primera letra
	        char actitud = sc.next().charAt(0);

	        sc.close();

	        // Llamamos al método y guardamos la nota ajustada
	        int notaFinal = evaluarAlumno(nota, actitud);

	        System.out.println("La nota final es: " + notaFinal);

	        if (notaFinal >= 5) {
	            System.out.println("El alumno ha aprobado");
	        } else {
	            System.out.println("El alumno ha suspendido");
	        }
	    }

	}

