package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//4.- Crear un programa que pida al usuario el total de una compra (decimal) y un código de cupón (String).
//Define un método propio llamado calcularTotalConDescuento que reciba el precio y el código. Si el código es
//igual a "OFERTA10" (ignorando mayúsculas/minúsculas), aplica un 10% de descuento con el operador -=. Si el
//código es "SUPER20", aplica un 20% con el operador -=. En cualquier otro caso no tiene descuento. Muestra el
//precio final redondeado a dos decimales usando la clase DecimalFormat.
public class Compras {

	// Método propio: recibe el precio y el código, y devuelve el precio final
    public static double calcularTotalConDescuento(double precio, String codigo) {

        if (codigo.equalsIgnoreCase("OFERTA10")) {
            precio -= precio * 0.10;   // Resta el 10% del precio

        } else if (codigo.equalsIgnoreCase("SUPER20")) {
            precio -= precio * 0.20;   // Resta el 20% del precio
        }
        // Con cualquier otro código no se hace nada: sin descuento

        return precio;
    }

    public static void main(String[] args) {

        // Pedimos los datos
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el total de la compra"));
        String codigo = JOptionPane.showInputDialog("Ingresa el código de cupón");

        // Llamamos al método y guardamos el precio final
        double precioFinal = calcularTotalConDescuento(precio, codigo);

        // "0.00" = siempre dos decimales
        DecimalFormat df = new DecimalFormat("0.00");

        JOptionPane.showMessageDialog(null, "El precio final es: " + df.format(precioFinal) + " €");
    }
}
