package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//5.- Solicita al usuario mediante JOptionPane la medida de los dos catetos de un triángulo rectángulo (números
//decimales). Crea un método propio llamado obtenerHipotenusa que calcule y devuelva la hipotenusa utilizando
//Math.sqrt y Math.pow con la fórmula hipotenusa = Raíz cuadrada(c1 cuadrado + c2 cuadrado). Luego, en el
//main, muestra el valor de la hipotenusa. Aplica control de decimales a la hipotenusa con 4 .
public class Catetos {

	// Método propio: recibe los dos catetos y DEVUELVE la hipotenusa
    public static double obtenerHipotenusa(double c1, double c2) {

        // Math.pow(x, 2) = x al cuadrado | Math.sqrt() = raíz cuadrada
        return Math.sqrt(Math.pow(c1, 2) + Math.pow(c2, 2));
    }

    public static void main(String[] args) {

        // Pedimos los dos catetos
        double c1 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer cateto"));
        double c2 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo cateto"));

        // Llamamos al método y guardamos la hipotenusa
        double hipotenusa = obtenerHipotenusa(c1, c2);

        // "0.0000" = siempre 4 decimales
        DecimalFormat df = new DecimalFormat("0.0000");

        JOptionPane.showMessageDialog(null, "La hipotenusa es: " + df.format(hipotenusa));
    }

}
