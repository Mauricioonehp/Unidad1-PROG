package EjerciciosMetodos;

import java.text.DecimalFormat;
import java.util.Scanner;

public class IMC_PROFE {

	public static void main(String[] args) {
		DecimalFormat x = new DecimalFormat("#0.##");
		Scanner ent = new Scanner(System.in);
		System.out.println("Introduzca su cintura en centimetros: ");
		double cintura = ent.nextDouble();
		System.out.println("Introduzca su altura en centímetros: ");
		int altura = ent.nextInt();
		System.out.println("Introduzca si es Hombre o Mujer (H/M): ");
		String sexo = ent.next();
		System.out.println("Introduzca su edad: ");
		int edad = ent.nextInt();
		ent.close();
		double ict = cintura / altura;
		double pgc_H = 106.5 * ict - 28.36;
		double pgc_M = 89.73 * ict - 15.14;
		if (edad < 20 || edad > 79)
			System.out.println("Intervalo de edades no válido");
		else {
			if (edad >= 20 && edad <= 39) {
				if (sexo.equalsIgnoreCase("H") && (pgc_H >= 8 && pgc_H <= 19))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_H) + ". Valores Sanos.");
				else if (sexo.equalsIgnoreCase("M") && (pgc_M >= 21 && pgc_M <= 32))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_M) + ". Valores Sanos.");
				else
					System.out.println("Su ICT es :" + x.format(ict) + " .\nSu PGC es : " + x.format(pgc_H)
							+ "(Hombre).\n " + x.format(pgc_M) + "(Mujer). Valores NO Sanos.");
			} else if (edad >= 40 && edad <= 59) {
				if (sexo.equalsIgnoreCase("H") && (pgc_H >= 11 && pgc_H <= 21))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_H) + ". Valores Sanos.");
				else if (sexo.equalsIgnoreCase("M") && (pgc_M >= 23 && pgc_M <= 33))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_H) + ". Valores Sanos.");
				else
					System.out.println("Su ICT es :" + x.format(ict) + " .\nSu PGC es : " + x.format(pgc_H)
							+ "(Hombre). \n" + x.format(pgc_M) + "(Mujer). Valores NO Sanos.");
			} else if (edad >= 60 && edad <= 79) {
				if (sexo.equalsIgnoreCase("H") && (pgc_H >= 13 && pgc_H <= 24))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_H) + ". Valores Sanos.");
				else if (sexo.equalsIgnoreCase("M") && (pgc_H >= 24 && pgc_H <= 35))
					System.out.println(
							"Su ICT es :" + x.format(ict) + " .Su PGC es : " + x.format(pgc_H) + ". Valores Sanos.");
				else
					System.out.println("Su ICT es :" + x.format(ict) + " .\nSu PGC es : " + x.format(pgc_H)
							+ "(Hombre). \n" + x.format(pgc_M) + "(Mujer). Valores NO Sanos.");
			}
		}
	}
}


