package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

public class IMC_GRAFICO {

    public static void main(String[] args) {

        DecimalFormat x = new DecimalFormat("#0.##");

        // ----- PEDIR LOS DATOS -----
        double cintura = Double.parseDouble(JOptionPane.showInputDialog("Introduzca su cintura en centímetros:"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Introduzca su altura en centímetros:"));
        String sexo = JOptionPane.showInputDialog("Introduzca si es Hombre o Mujer (H/M):");
        int edad = Integer.parseInt(JOptionPane.showInputDialog("Introduzca su edad:"));

        // ----- ÚNICO CONTROL: edad entre 20 y 79 -----
        if (edad < 20 || edad > 79) {
            JOptionPane.showMessageDialog(null, "Intervalo de edades no válido");
            main(null);   // Reinicia la aplicación
            return;
        }

        // ----- ICT -----
        double ict = cintura / altura;

        // ----- %G, y límites sanos según género y edad -----
        double pgc;
        double min;
        double max;

        if (sexo.equalsIgnoreCase("H")) {
            pgc = 106.5 * ict - 28.36;

            if (edad <= 39) {
                min = 8;  max = 19;
            } else if (edad <= 59) {
                min = 11; max = 21;
            } else {
                min = 13; max = 24;
            }

        } else {
            pgc = 89.73 * ict - 15.14;

            if (edad <= 39) {
                min = 21; max = 32;
            } else if (edad <= 59) {
                min = 23; max = 33;
            } else {
                min = 24; max = 35;
            }
        }

        // ----- MOSTRAR RESULTADO -----
        String mensaje = "Su ICT es: " + x.format(ict) + "\nSu PGC es: " + x.format(pgc) + " %\n";

        if (pgc >= min && pgc <= max) {
            JOptionPane.showMessageDialog(null, mensaje + "Valores Sanos");
        } else {
            JOptionPane.showMessageDialog(null, mensaje + "Valores NO Sanos");
        }
    }
}