package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

/*
 * Índice Cintura-Talla (ICT) y porcentaje de grasa corporal (%G), con botones.
 *   ICT = cintura (cm) / altura (cm)
 *   Hombres: %G = 106,5 * ICT - 28,36
 *   Mujeres: %G = 89,73 * ICT - 15,14
 * El género y el intervalo de edad se eligen con botones (showOptionDialog),
 * por eso no hace falta validar la edad.
 */
public class Grafico_Merjorado {

    public static void main(String[] args) {

        // ===================== 1) PEDIR LOS DATOS =====================

        double cintura = Double.parseDouble(JOptionPane.showInputDialog(null, "Inserte el perímetro de su cintura en cm"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Inserte su altura en cm"));

        // showOptionDialog devuelve la POSICIÓN del botón pulsado:
        // sexo:   0 = Hombre, 1 = Mujer          (-1 si se cierra con la X)
        // edades: 0 = 20-39, 1 = 40-59, 2 = 60-79 (-1 si se cierra con la X)
        int sexo = JOptionPane.showOptionDialog(null, "Seleccione su sexo", "Porcentaje Grasa Corporal",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[] { "Hombre", "Mujer" }, null);

        int edades = JOptionPane.showOptionDialog(null, "Seleccione su edad", "Porcentaje Grasa Corporal",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[] { "20-39", "40-59", "60-79" }, null);

        // Si el usuario cierra alguna ventana con la X, terminamos el programa
        if (sexo == -1 || edades == -1) {
            System.exit(0);
        }

        // ===================== 2) CALCULAR EL ICT =====================

        double ict = cintura / altura;

        // ===================== 3) CALCULAR EL %G Y LOS LÍMITES SANOS =====================

        double pgc;   // porcentaje de grasa corporal del usuario
        double min;   // límite inferior del intervalo sano
        double max;   // límite superior del intervalo sano

        if (sexo == 0) {
            // ----- HOMBRE -----
            pgc = 106.5 * ict - 28.36;

            if (edades == 0) {          // 20-39 años
                min = 8;
                max = 19;
            } else if (edades == 1) {   // 40-59 años
                min = 11;
                max = 21;
            } else {                    // 60-79 años
                min = 13;
                max = 24;
            }

        } else {
            // ----- MUJER -----
            pgc = 89.73 * ict - 15.14;

            if (edades == 0) {          // 20-39 años
                min = 21;
                max = 32;
            } else if (edades == 1) {   // 40-59 años
                min = 23;
                max = 33;
            } else {                    // 60-79 años
                min = 24;
                max = 35;
            }
        }

        // ===================== 4) MOSTRAR EL RESULTADO =====================

        // "0.00" = siempre 2 decimales
        DecimalFormat x = new DecimalFormat("0.00");

        // El %G está dentro del intervalo sano si es >= min y <= max
        if (pgc >= min && pgc <= max) {
            JOptionPane.showMessageDialog(null, "Está sano y su PGC es " + x.format(pgc));
        } else {
            JOptionPane.showMessageDialog(null, "No está sano y su PGC es " + x.format(pgc));
        }
    }
}