package EjerciciosMetodos;

import java.util.Scanner;

//Solicita al usuario las coordenadas Cartesianas (x1, y1) y (x2, y2) de dos puntos (decimales) mediante
//Scanner. Diseña un método propio void llamado calcularDistancia que reciba las coordenadas y muestre la
//distancia absoluta entre ambos puntos x e y utilizando Math.abs.
public class Coordenadas {
	
//	public static void calcularDistancia(double x1, double y1, double x2, double y2) {
////		double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
//		 double difX = Math.abs(x1 - x2);
//		 double difY = Math.abs(y1 - y2);
//		 System.out.println("La distancia entre x es "+difX+" y la distancia entre y es "+difY);
//		 }
//
//
//	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
//		 System.out.print("Introduce la coordenada X1: ");
//		 double x1 = scanner.nextDouble();
//		 System.out.print("Introduce la coordenada Y1: ");
//		 double y1 = scanner.nextDouble();
//		 System.out.print("Introduce la coordenada X2: ");
//		 double x2 = scanner.nextDouble();
//		 System.out.print("Introduce la coordenada Y2: ");
//		 double y2 = scanner.nextDouble();
//		 scanner.close();
//		 calcularDistancia(x1, y1, x2, y2);
//		 }


	
	// Método void: calcula y muestra, no devuelve nada
    public static void calcularDistancia(double x1, double y1, double x2, double y2) {

        // Fórmula de la distancia: raíz de (x2-x1)^2 + (y2-y1)^2
        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        System.out.println("La distancia entre los dos puntos es " + distancia);
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la coordenada X1: ");
        double x1 = sc.nextDouble();
        System.out.print("Introduce la coordenada Y1: ");
        double y1 = sc.nextDouble();
        System.out.print("Introduce la coordenada X2: ");
        double x2 = sc.nextDouble();
        System.out.print("Introduce la coordenada Y2: ");
        double y2 = sc.nextDouble();

        sc.close();

        calcularDistancia(x1, y1, x2, y2);
    }
}
	


