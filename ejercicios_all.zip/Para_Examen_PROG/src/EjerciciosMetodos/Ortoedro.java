package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

/*
 * Calcular el volumen de un ortoedro (largo * ancho * alto).
 * - Las peticiones de los lados se hacen en el main.
 * - Los cálculos y la visualización se hacen en un método void, que controla
 *   que los lados sean positivos; si no, reinicia la aplicación.
 * - El resultado siempre con dos decimales.
 */
public class Ortoedro {

    // Método void: calcula, controla y muestra (no devuelve nada)
    public static void volumen(double largo, double ancho, double alto) {

        // Los lados deben ser positivos (mayores que 0)
        if (largo <= 0 || ancho <= 0 || alto <= 0) {
            JOptionPane.showMessageDialog(null, "Los lados deben ser positivos");
            main(null);   // Reinicia la aplicación: vuelve a pedir los lados

        } else {
            double volumen = largo * ancho * alto;

            // "0.00" = siempre dos decimales (24 se muestra como 24,00)
            DecimalFormat df = new DecimalFormat("0.00");

            JOptionPane.showMessageDialog(null, "El volumen del ortoedro es: " + df.format(volumen));
        }
    }

    public static void main(String[] args) {
        // Las peticiones se hacen aquí, en el main

        double largo = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el largo"));
        double ancho = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el ancho"));
        double alto = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el alto"));
        // Llamamos al método pasándole los tres lados

        volumen(largo, ancho, alto);
    }
}