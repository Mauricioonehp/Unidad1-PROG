package EjerciciosMetodos;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

//3.- Crear un programa que calcule el perímetro de una circunferencia aplicando la fórmula P = 2 * PI * r.
//Usaremos Math.PI y pediremos solamente el radio en el main, mientras que el cálculo y visualización del
//resultado se hará en un método con tipo devuelto double que controlará que el radio no sea menor de 0.0 o
//reiniciará la aplicación. Obtener siempre dos decimales.
public class Perimetro {


		// Método que DEVUELVE un double: calcula, muestra y devuelve el perímetro
	    public static double perimetro(double radio) {

	        // El radio no puede ser menor de 0.0
	        if (radio < 0.0) {
	            JOptionPane.showMessageDialog(null, "El radio no puede ser negativo");
	            main(null);    // Reinicia la aplicación: vuelve a pedir el radio
	            
	        }

	        double perimetro = 2 * Math.PI * radio;

	        // "0.00" = siempre dos decimales
	        DecimalFormat df = new DecimalFormat("0.00");

	        JOptionPane.showMessageDialog(null, "El perímetro de la circunferencia es: " + df.format(perimetro));

	        return perimetro;   // Devuelve el valor calculado
	    }

	    public static void main(String[] args) {

	        // Solo se pide el radio, aquí en el main
	        double radio = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el radio"));

	        // Llamamos al método (el valor devuelto no se usa porque ya se muestra dentro)
	        perimetro(radio);
	}

}
