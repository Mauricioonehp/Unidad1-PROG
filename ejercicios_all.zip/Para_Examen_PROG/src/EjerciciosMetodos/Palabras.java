package EjerciciosMetodos;

import javax.swing.JOptionPane;

//9.- Pedir al usuario tres palabras (Strings) mediante JOptionPane. Crear dos métodos propios llamados
//obtenerMayor y obtenerMenor que calculen la longitud de la cadena más larga/corta usando la clase Math. En el
//main verificar primero si alguna de las tres palabras son nulas avisar al usuario y volver a lanzar la app.
//Después indicar si las tres longitudes son idénticas o no mostrando los valores finales obtenidos.

public class Palabras {

	public static void main(String[] args) {
		String palabra1 = JOptionPane.showInputDialog("Introduce la primera palabra:");
		String palabra2 = JOptionPane.showInputDialog("Introduce la segunda palabra:");
		String palabra3 = JOptionPane.showInputDialog("Introduce la segunda palabra:");
		if (palabra1.length() == 0 || palabra2.length() == 0 || palabra3.length() == 0) {
		JOptionPane.showMessageDialog(null,
		"Algunas de las palabras tiene longitud cero. Inténtelo de nuevo");
		main(null);
		}
		int mayor = obtenerMayor(palabra1, palabra2, palabra3);
		int menor = obtenerMenor(palabra1, palabra2, palabra3);
		if (mayor==menor) {
		JOptionPane.showMessageDialog(null,
		"Todas las longitudes son iguales a "+ mayor);
		} else {
		JOptionPane.showMessageDialog(null,"Las palabras son diferentes.\nMayor: "+mayor+"\nMenor: "+menor);
		}
		}
		public static int obtenerMayor(String p1, String p2, String p3) {
		int len1 = p1.length();
		int len2 = p2.length();
		int len3 = p3.length();
		return Math.max(len3, Math.max(len1, len2));
		}
		public static int obtenerMenor(String p1, String p2, String p3) {
		int len1 = p1.length();
		int len2 = p2.length();
		int len3 = p3.length();
		return Math.min(len3, Math.min(len1, len2));
		}

    }

//// Devuelve la longitud de la cadena MÁS LARGA
//public static int obtenerMayor(String p1, String p2, String p3) {
//    return Math.max(p1.length(), Math.max(p2.length(), p3.length()));
//}
//
//// Devuelve la longitud de la cadena MÁS CORTA
//public static int obtenerMenor(String p1, String p2, String p3) {
//    return Math.min(p1.length(), Math.min(p2.length(), p3.length()));
//}
//
//public static void main(String[] args) {
//
//    // Pedimos las tres palabras
//    String p1 = JOptionPane.showInputDialog("Ingresa la primera palabra");
//    String p2 = JOptionPane.showInputDialog("Ingresa la segunda palabra");
//    String p3 = JOptionPane.showInputDialog("Ingresa la tercera palabra");
//
//    // showInputDialog devuelve null si se pulsa Cancelar o se cierra la ventana
//    if (p1 == null || p2 == null || p3 == null) {
//        JOptionPane.showMessageDialog(null, "Alguna palabra es nula, vuelve a intentarlo");
//        main(null);   // Reinicia la aplicación
//        return;       // Evita seguir con datos nulos al terminar la repetición
//    }
//
//    // Llamamos a los métodos y guardamos las longitudes
//    int mayor = obtenerMayor(p1, p2, p3);
//    int menor = obtenerMenor(p1, p2, p3);
//
//    // Si la más larga y la más corta miden lo mismo, las tres son idénticas
//    if (mayor == menor) {
//        JOptionPane.showMessageDialog(null,
//                "Las tres longitudes son idénticas"
//                + "\nLongitud mayor: " + mayor
//                + "\nLongitud menor: " + menor);
//    } else {
//        JOptionPane.showMessageDialog(null,
//                "Las tres longitudes NO son idénticas"
//                + "\nLongitud mayor: " + mayor
//                + "\nLongitud menor: " + menor);
//    }
//}

