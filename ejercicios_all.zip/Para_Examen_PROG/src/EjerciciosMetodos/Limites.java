package EjerciciosMetodos;

import javax.swing.JOptionPane;

//Pide al usuario un número límite inferior y un número límite superior (ambos decimales). Diseña un método
//propio generarAleatorioEnRango que genere y devuelva un entero aleatorio contenido estrictamente dentro de
//ese rango usando Math.random() y casting a int. Para ello, aplica la fórmula num = min + (Math.random() *
//(max - min)). En el main, mediante controles if, verifica previamente que el límite superior sea estrictamente
//mayor que el inferior; si no lo es, muestra un mensaje de error mediante JOptionPane y reinicia la aplicación
public class Limites {

	// Método propio: recibe los dos límites y DEVUELVE un entero aleatorio
    public static int generarAleatorioEnRango(double min, double max) {

        // Math.random() da un decimal entre 0 (incluido) y 1 (excluido)
        // El cast (int) corta los decimales para quedarnos con un entero
        int num = (int) (min + (Math.random() * (max - min)));

        return num;
    }

    public static void main(String[] args) {

        double min = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el límite inferior"));
        double max = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el límite superior"));

        // El superior tiene que ser ESTRICTAMENTE mayor que el inferior
        if (max <= min) {
            JOptionPane.showMessageDialog(null, "Error: el límite superior debe ser mayor que el inferior");
            main(null);   // Reinicia la aplicación
            return;       // Evita seguir con los datos incorrectos al terminar la repetición
        }

        // Llamamos al método y guardamos el número generado
        int num = generarAleatorioEnRango(min, max);

        JOptionPane.showMessageDialog(null, "Número aleatorio entre " + min + " y " + max + ": " + num);
    }
    
    
//    
//    public static void main(String[] args) {
//
//        double min = Double.parseDouble(JOptionPane.showInputDialog("Introduce el límite inferior:"));
//        double max = Double.parseDouble(JOptionPane.showInputDialog("Introduce el límite superior:"));
//
//        // El superior tiene que ser ESTRICTAMENTE mayor que el inferior
//        if (max <= min) {
//            JOptionPane.showMessageDialog(null, "Error: el límite superior debe ser mayor que el inferior.");
//            main(null);
//        } else {
//            int numeroGenerado = generarAleatorioEnRango(min, max);
//            JOptionPane.showMessageDialog(null, "El número entero aleatorio generado en el rango es: " + numeroGenerado);
//        }
//    }
//
//    public static int generarAleatorioEnRango(double min, double max) {
//        double aleatorioDecimal = min + (Math.random() * (max - min));
//        return (int) aleatorioDecimal;
//    }
//}
}
