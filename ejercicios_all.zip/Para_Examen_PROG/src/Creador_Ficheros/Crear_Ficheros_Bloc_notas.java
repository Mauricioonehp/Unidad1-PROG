package Creador_Ficheros;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Crear_Ficheros_Bloc_notas {

	public static void main(String[] args) throws IOException {

		// El booleano indica append=true para añadir. Si no lo pusiéramos o
		// le ponemos false indica sobreescribir
		// Filewriter(String ruta, boolean)
		
		
		FileWriter fichero =new FileWriter("docu.txt", true); //false es para sobre escribir en el mismo 
		
		PrintWriter pw = new PrintWriter(fichero);

		fichero.write("\nNombre del empleado: Mauricio"); // Escritura del fichero
		
		pw.println(); // cambio de linea
		
		fichero.write("Codigo de empleado: 123");
		
		pw.println();
		
		pw.flush(); //vaciado de buffer de escritura
		
		fichero.flush();
		
		
		pw.close(); //cierre del objeto
		fichero.close();
		
		//Apertura del fichero posterior - Solo en Windows
//		
//	Runtime.getRuntime().exec(
//				"rundll32 url.dll,FileProtocolHandler "+"D:/docu.txt"); // ACUERDATE DE LOS ESPACIOS SI UN ESPACIO FALTA NO EJECUTA EL CODIGO MIRAAAAAAAAAAA
//		
		Desktop.getDesktop().open(new File("docu.txt"));  //ES LO MISMO SIN TANTOS ERRORES POR ESPACIOS
		
		
	}
}
