package Relacionales;

import java.util.Scanner;

public class Relacionaless {

	public static void main(String[] args) {
	
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduzca el primer número: ");
		
		double a =sc.nextDouble();
		
		System.out.println("Introduzca el segundo número: ");
		
		double b =sc.nextDouble();
		
		sc.close();
			if (a == b)
				
			System.out.println("Es verdadero");
			
			else System.out.println("Es falso");

	}

}
