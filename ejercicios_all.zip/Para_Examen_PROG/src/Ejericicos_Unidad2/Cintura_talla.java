package Ejericicos_Unidad2;

import javax.swing.JOptionPane;

/*5º.- Calcular el Índice Cintura-Talla (ICT).
*      ICT = perímetro de cintura (cm) / altura (cm)
*      ICT <= 0,5 -> normal
*      ICT >  0,5 -> propensión a enfermedades cardiovasculares
*/
public class Cintura_talla {

	public static void main(String[] args) {
		 // Pedimos los dos datos en centímetros (decimales)
        double cintura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el perímetro de la cintura (cm)"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la altura (cm)"));

        // Fórmula del enunciado
        double ict = cintura / altura;

        // <= 0.5 es normal; en cualquier otro caso (> 0.5) hay propensión
        if (ict <= 0.5) {
            JOptionPane.showMessageDialog(null, "Tu ICT es " + ict + "\nValor NORMAL");
        } else {
            JOptionPane.showMessageDialog(null, "Tu ICT es " + ict
                    + "\nPropensión a las enfermedades cardiovasculares");
        }
	}

}
