package Ejericicos_Unidad2;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

public class ICT_GRASA {

	 public static void main(String[] args) {

	        // ----- PEDIR LOS DATOS -----
	        double cintura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el perímetro de la cintura (cm)"));
	        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la altura (cm)"));
	        String sexo = JOptionPane.showInputDialog("Ingresa tu sexo (H = hombre, M = mujer)");
	        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tu edad"));

	        // La tabla solo cubre de 20 a 79 años y el sexo debe ser H o M
	        if (edad < 20 || edad > 79 || !(sexo.equalsIgnoreCase("H") || sexo.equalsIgnoreCase("M"))) {
	            JOptionPane.showMessageDialog(null, "Datos no válidos (edad entre 20 y 79, sexo H o M)");
	            main(null);   // Reinicia la aplicación
	            return;       // Evita seguir con datos incorrectos al terminar la repetición
	        }

	        // ----- APARTADO 5: ICT -----
	        double ict = cintura / altura;

	        DecimalFormat df = new DecimalFormat("0.00");
	        String resultadoIct;

	        if (ict <= 0.5) {
	            resultadoIct = "ICT NORMAL";
	        } else {
	            resultadoIct = "ICT con propensión a enfermedades cardiovasculares";
	        }

	        // ----- APARTADO 6: %G Y LÍMITES SANOS SEGÚN LA TABLA -----
	        double grasa;
	        double min;   // límite inferior del %GC sano
	        double max;   // límite superior del %GC sano

	        if (sexo.equalsIgnoreCase("H")) {
	            // HOMBRES
	            grasa = 106.5 * ict - 28.36;

	            if (edad <= 39) {          // 20-39
	                min = 8;  max = 19;
	            } else if (edad <= 59) {   // 40-59
	                min = 11; max = 21;
	            } else {                   // 60-79
	                min = 13; max = 24;
	            }

	        } else {
	            // MUJERES
	            grasa = 89.73 * ict - 15.14;

	            if (edad <= 39) {          // 20-39
	                min = 21; max = 32;
	            } else if (edad <= 59) {   // 40-59
	                min = 23; max = 33;
	            } else {                   // 60-79
	                min = 24; max = 35;
	            }
	        }

	        // El %G es sano si está dentro del intervalo (límites incluidos)
	        String resultadoGrasa;

	        if (grasa >= min && grasa <= max) {
	            resultadoGrasa = "%GC Sana";
	        } else {
	            resultadoGrasa = "%GC No Sana";
	        }

	        // ----- MOSTRAR TODO -----
	        JOptionPane.showMessageDialog(null,
	                "ICT: " + df.format(ict) + " -> " + resultadoIct
	                + "\n%G: " + df.format(grasa) + " % -> " + resultadoGrasa);
	    }
	}


