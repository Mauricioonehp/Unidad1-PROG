package Ejericicos_Unidad2;

import javax.swing.JOptionPane;

public class Tobillo_brazo {
	/*
	 * 8º.- Calcular el Índice Tobillo-Brazo (ITB).
	 *      ITB = presión arterial más alta de la pierna / presión arterial más alta del brazo
	 *      Valor obtenido    Interpretación
	 *      sobre 1,2         Anormal
	 *      1,0 - 1,2         Normal
	 *      0,9 - 1,0         Aceptable
	 *      0,8 - 0,9         Enfermedad arterial
	 *      0,5 - 0,8         Enfermedad arterial moderada
	 *      menor de 0,5      Enfermedad arterial severa
	 */
	public static void main(String[] args) {
		 // ----- PEDIR LOS DATOS -----
        double pierna = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la presión más alta de la pierna"));
        double brazo = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la presión más alta del brazo"));

        // ----- CALCULAR EL ITB (cociente pierna / brazo) -----
        double itb = pierna / brazo;

        String interpretacion;

        // Se comprueba de mayor a menor
        if (itb > 1.2) {
            interpretacion = "Anormal";
        } else if (itb >= 1.0) {           // de 1,0 a 1,2
            interpretacion = "Normal";
        } else if (itb >= 0.9) {           // de 0,9 a 1,0 (sin llegar a 1,0)
            interpretacion = "Aceptable";
        } else if (itb >= 0.8) {           // de 0,8 a 0,9
            interpretacion = "Enfermedad arterial";
        } else if (itb >= 0.5) {           // de 0,5 a 0,8
            interpretacion = "Enfermedad arterial moderada";
        } else {                           // menor de 0,5
            interpretacion = "Enfermedad arterial severa";
        }

        JOptionPane.showMessageDialog(null, "Tu ITB es " + Math.round(itb * 100) / 100.0
                + "\nInterpretación: " + interpretacion);
    }

	}


