package Ejericicos_Unidad2;

import javax.swing.JOptionPane;

public class ICC_CINTURA_CADERA {

	public static void main(String[] args) {
		// ----- PEDIR LOS DATOS -----
        double cintura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el perímetro de la cintura (cm)"));
        double cadera = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el perímetro de la cadera (cm)"));
        String sexo = JOptionPane.showInputDialog("Ingresa tu sexo (H = hombre, M = mujer)");

        // El sexo debe ser H o M; si no, avisamos y reiniciamos
        if (!(sexo.equalsIgnoreCase("H") || sexo.equalsIgnoreCase("M"))) {
            JOptionPane.showMessageDialog(null, "Sexo no válido (escribe H o M)");
            main(null);
            return;
        }

        // ----- CALCULAR EL ICC -----
        double icc = cintura / cadera;

        String riesgo;

        if (sexo.equalsIgnoreCase("H")) {
            // HOMBRES
            if (icc > 0.95) {
                riesgo = "ALTO";
            } else if (icc >= 0.90) {      // de 0,90 a 0,95
                riesgo = "MODERADO";
            } else {                       // menor que 0,90
                riesgo = "BAJO";
            }

        } else {
            // MUJERES
            if (icc > 0.85) {
                riesgo = "ALTO";
            } else if (icc >= 0.80) {      // de 0,80 a 0,85
                riesgo = "MODERADO";
            } else {                       // menor que 0,80
                riesgo = "BAJO";
            }
        }

        JOptionPane.showMessageDialog(null, "Tu ICC es " + Math.round(icc * 100) / 100.0
                + "\nRiesgo cardíaco: " + riesgo);
    }
	}


