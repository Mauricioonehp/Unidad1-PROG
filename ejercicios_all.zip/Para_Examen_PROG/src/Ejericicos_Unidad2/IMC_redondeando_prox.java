package Ejericicos_Unidad2;

import javax.swing.JOptionPane;

public class IMC_redondeando_prox {

	public static void main(String[] args) {
		// Peso como entero y altura como decimal
        int peso = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tu peso en kilos (entero)"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa tu altura en metros (decimal)"));

        // IMC redondeado al entero más próximo (Math.round + cast a int)
        int imc = (int) Math.round(peso / (altura * altura));

        // Los rangos se comprueban de menor a mayor
        if (imc < 16) {
            JOptionPane.showMessageDialog(null, "INFRAPESO\nTu IMC es " + imc);

        } else if (imc < 25) {          // 16 hasta 24
            JOptionPane.showMessageDialog(null, "PESO IDEAL\nTu IMC es " + imc);

        } else if (imc < 30) {          // 25 hasta 29
            JOptionPane.showMessageDialog(null, "SOBREPESO\nTu IMC es " + imc);

        } else if (imc <= 40) {         // 30 hasta 40
            JOptionPane.showMessageDialog(null, "OBESO\nTu IMC es " + imc);

        } else {                        // más de 40
            JOptionPane.showMessageDialog(null, "PELIGRO. OBESIDAD MÓRBIDA");
        }
	}

}
