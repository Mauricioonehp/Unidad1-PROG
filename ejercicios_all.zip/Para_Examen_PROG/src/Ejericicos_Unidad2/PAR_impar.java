package Ejericicos_Unidad2;

import javax.swing.JOptionPane;

public class PAR_impar {

	public static void main(String[] args) {
		// Pedimos un número entero
        int numero = Integer.parseInt(JOptionPane.showInputDialog("Ingresa un número"));

        // % devuelve el RESTO de la división.
        // Si al dividir entre 2 el resto es 0, el número es par
        if (numero % 2 == 0) {
            JOptionPane.showMessageDialog(null, numero + " es par");
        } else {
            JOptionPane.showMessageDialog(null, numero + " es impar");
        }
	}

}
