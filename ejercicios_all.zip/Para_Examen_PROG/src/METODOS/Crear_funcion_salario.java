package METODOS;

import java.util.Scanner;

/*
 * 4º.- Crear una función que calcule el salario mayor de tres pedidos
 *      y mostrarlo.
 */
public class Crear_funcion_salario {
    // Función que recibe tres salarios y devuelve el mayor

	public static double salarios(double salario1,double salario2,double salario3) {
		
        // Math.max compara dos valores; lo usamos dos veces para comparar tres
		// con if seria asi : 
//				public static double salarioMayor(double s1, double s2, double s3) {
//				    double mayor = s1;          // Suponemos que el primero es el mayor
//
//				    if (s2 > mayor) {
//				        mayor = s2;             // El segundo es mayor que el actual
//				    }
//				    if (s3 > mayor) {
//				        mayor = s3;             // El tercero es mayor que el actual
//				    }
//				    return mayor;
//				}
//		
		

		return Math.max(salario1, Math.max(salario2, salario3));
		
		
	}
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa un salario");
		double salario1 = sc.nextDouble();
		System.out.println("Ingresa otro salario");
		double salario2 = sc.nextDouble();
		System.out.println("Ingresa otro salario");
		double salario3=sc.nextDouble();
		sc.close();
        // Llamamos a la función y mostramos el resultado

		double Smayor=salarios(salario1, salario2, salario3);
		
		System.out.println("El salairo mayor es : "+Smayor);
		
		
		
		
	}

}
