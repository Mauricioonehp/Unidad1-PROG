package METODOS;

import java.util.Scanner;

/*
 * 3º.- Crear una función para una empresa de divisas que convierta
 *      dólares a euros. La cantidad de dólares y el tipo de cambio son
 *      variables (actualmente 1 $ = 1,11 €).
 *      Hay que restarle una comisión: el valor MAYOR entre el 1% de los
 *      dólares a cambiar o un fijo de 5 €.
 *      Mostrar los euros redondeados al entero superior.
 */
public class Cambio_moneda {
	

	public static int dolaresAEuros(double dolares, double cambio) {

	    // 1) Convertimos los dólares a euros
	    double euros = dolares * cambio;

	    // 2) Comisión: el mayor entre el 1% de los dólares y 5 €
	    double comision = Math.max(dolares * 0.01, 5);

	    // 3) Restamos la comisión
	    euros -= comision;

	    // 4) Quitamos el error de precisión redondeando a 2 decimales
	    //    (106.00000000000001 -> 106.0)
	    euros = Math.round(euros * 100) / 100.0;

	    // 5) Redondeamos al entero superior
	    return (int) Math.ceil(euros);
	}

	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.println("Ingresa la cantidad de dólares");
	        double dolares = sc.nextDouble();

	        System.out.println("Ingresa el tipo de cambio (actualmente 1,11)");
	        double cambio = sc.nextDouble();

	        sc.close();

	        // Llamamos a la función y mostramos el resultado
	        int euros = dolaresAEuros(dolares, cambio);
	        System.out.println("Recibirás " + euros + " €");
	    }
	}