package METODOS;

import java.util.Scanner;

public class Metod0s {

	
	public static String S(String name) {
		
		String S ="name";
		return S;
		
	}
	
	
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); 
		System.out.println("ingresa tu nombre");
		String name = sc.toString();
		System.out.println("adadwd"+name);
		sc.close();
		
		
		
	
	}

}
