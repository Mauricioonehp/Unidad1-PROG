package METODOS;

public class Metodos_ {

	static double salario=1000;
	public static double aumento (int porcentaje) {		//Debe ser double

		return salario=salario+salario*(porcentaje/100) ;		
					//----------------------------------------
					//Valor truncado a 0
	}

	
	
	public static void main(String[] args) {

		double resul= aumento(20);
		System.out.println(resul);
			}
		}
		

	
	