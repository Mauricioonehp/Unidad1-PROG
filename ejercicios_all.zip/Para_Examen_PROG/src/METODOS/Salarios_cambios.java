package METODOS;

import java.util.Scanner;
/*
 * 6º.- Función que aumente o disminuya el salario según suba o baje
 *      el IPC (en %), recibiendo ambos valores y redondeando el
 *      salario actualizado.
 */
public class Salarios_cambios {

	public static int actualizacionS(double salario , double IPC) {
		 // Si el IPC es positivo, el salario sube; si es negativo, baja.
        // Ejemplo: IPC 3  -> * 1.03  |  IPC -2 -> * 0.98
		salario *=(1+IPC/100);
		 // Math.round() redondea al entero MÁS PRÓXIMO. Devuelve long, por eso el cast (int)
		return (int) Math.round(salario);
		
	}
	
	public static void main(String[] args) {
		
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("ingresa el monto del salario ");
		
		double salario = sc.nextDouble();
		
		System.out.println("Ingresa el monto del IPC (SI ES NEGATIVO BAJA)");
		double IPC=sc.nextDouble();
		sc.close();
		
		int nuevosalario=actualizacionS(salario, IPC);
		System.out.println("El salario actualizado es de ; "+nuevosalario);
	}

}
