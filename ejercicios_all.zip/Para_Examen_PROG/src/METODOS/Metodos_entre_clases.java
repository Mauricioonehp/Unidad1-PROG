package METODOS;

public class Metodos_entre_clases {

	
	public static double sumar(double x, double y) {
		double result = x+y;
		
		return result;
		
	}
	
	public static void saludo()  
		{
			System.out.println("Buenos días");
		}

	
	public static void main(String[] args) {
		
		double r = sumar(12.2,12.3);			//Código habitual con 
        System.out.println(r);				//invocaciones a funciones

		
	saludo();
	
	despedida();
	}
	
	public static void despedida() {
		
		System.out.println("ADIOS");
	}

	}


