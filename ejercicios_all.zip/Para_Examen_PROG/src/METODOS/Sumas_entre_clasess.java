package METODOS;

import java.util.Scanner;

//1º.- Crear la clase Aritmética que contenga dos funciones estáticas suma1 y suma2 que sume dos números reales con return y con void 
//		y se pidan al usuario. Por otro lado, haremos la aplicación en otro archivo. Recordaremos la forma correcta de acceder a los métodos estáticos. 




public class Sumas_entre_clasess {
	
	public static Double sum(double sum1,double sum2) {
		
		double suma=sum1+sum2;
		 
		return suma;
	}
	
	public static void main(String[] args) {

		
		Scanner sc=new Scanner(System.in);
		System.out.println("ingresa un numero a sumar");
		double sum1 = sc.nextDouble();
		System.out.println("ingresa un numero a sumar");
		double sum2 = sc.nextDouble();
		sc.close();
		
		System.out.println("la suma de los 2 numeros es "+sum(sum1, sum2));
	}

}
