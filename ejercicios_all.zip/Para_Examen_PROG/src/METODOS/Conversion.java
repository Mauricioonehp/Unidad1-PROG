package METODOS;

import java.util.Scanner;

/*
 * 2º.- Crear la clase Conversión que contenga una función que reciba
 *      una temperatura en grados Fahrenheit y la devuelva en Celsius.
 *      Fórmula: C = (F - 32) * 5/9
 *      Convertir a int el resultado y mostrarlo redondeado sin decimales.
 */
public class Conversion {

    // Función que recibe Fahrenheit y devuelve Celsius
    public static int fahrenheitACelsius(double f) {

        // OJO: se usa 5.0 / 9 (decimal). Si pusieras 5 / 9 con enteros,
        // Java daría 0 y el resultado siempre sería 0.
        double celsius = (f - 32) * 5.0 / 9;

        // Convertimos a int con cast: elimina los decimales (trunca)
        return (int) celsius;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingresa la temperatura en grados Fahrenheit");
        double fahrenheit = sc.nextDouble();
        sc.close();

        // Llamamos a la función y guardamos el resultado
        int celsius = fahrenheitACelsius(fahrenheit);

        System.out.println(fahrenheit + " °F son " + celsius + " °C");
    }
}