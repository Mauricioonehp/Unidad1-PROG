package METODOS;

import java.util.Scanner;

/*
 * 5º.- Crear una función a la que se le pasen dos salarios (el mayor y el
 *      menor de una empresa, en indistinto orden) y muestre:
 *      - la diferencia salarial en valor positivo y sin decimales
 *      - las veces que gana más el mayor que el menor (mayor / menor),
 *        redondeado al entero más próximo.
 *      Realizar los cast oportunos.
 */
public class Diferencias_salariales {
	
	public static void diferencias(double salario1 , double salario2) {
        // Como el orden es indistinto, averiguamos cuál es el mayor y el menor

		double mayor = Math.max(salario1, salario2);
		double menor = Math.min(salario1, salario2);
		
		// Diferencia siempre positiva (mayor - menor).
        // (int) = cast que TRUNCA: quita los decimales ("sin decimales")
		
		int dif=(int)(mayor-menor);
		System.out.println("la diferencia salarial es de "+dif);
		
		 // Se divide con double para NO perder decimales (con int daría 4500/1200 = 3).
        // Math.round() = redondea al entero MÁS PRÓXIMO (3.75 -> 4).
        // Devuelve long, por eso lleva el cast (int).
		
		int veces =(int) Math.round(mayor/menor);
		
		System.out.println("El mayor gana " + veces + " veces más que el menor");
		
	}
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingresa un salario");
		double salario1 =sc.nextDouble();
		System.out.println("Ingresa un salario");
		double salario2 =sc.nextDouble();
		sc.close();
        // Llamamos a la función pasándole los dos salarios

		diferencias(salario1, salario2);
	}

}
