package ASIGNACIONES;

public class Ejercicio_Suma_restar {
//	
//	2º.- Asignar a las variables Luis, Marta y Juan las notas 2, 6 y 9 respectivamente como variables. Incrementar en dos unidades la de Luis.
//	Decrementar en una unidad la de Marta y también la de Juan, dividiendo la de Juan por dos. 
//	Luego a Marta aplicarla el operador asigna y suma con Luis y a Juan aplicar el operador resta y asigna con Luis. Las variables deben mostrar los valores 
	
	
	public static void main(String[] args) {
		
		int Luis =2;
		int Marta=6;
		int Juan=9;
		
		Luis +=2; 	// Luis = 2 + 2 = 4
		Marta--; 	// Marta = 6 - 1 = 5
		Juan --;	// Juan = 9 - 1 = 8
		
		Juan /=2;	 // Juan = 8 / 2 = 4
		
		
		// OJO: "=+" NO es "+=".
        // Java lo lee como: Marta = (+Luis), es decir, una asignación normal.
        // Por eso Marta pasa a valer 4 (el valor de Luis) y no 9.
		
		Marta=+Luis; // Marta = 4	
		
		Juan-=Luis;  // Juan = 4 - 4 = 0
		
		System.out.println("Marta: "+ Marta +" Luis "+Luis+" Juan: "+Juan);
		
			
	}

}
