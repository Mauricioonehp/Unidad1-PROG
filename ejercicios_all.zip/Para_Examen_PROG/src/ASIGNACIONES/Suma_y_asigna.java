package ASIGNACIONES;

public class Suma_y_asigna {

	public static void main(String[] args) {

		int var = 0;
		var += 3; // equivale a Var + 3 = Var
		System.out.println(var);
		var = +5; // equivale a Var = 5
		System.out.println(var);
		
		int a = 1;
		int c = ++a;	//  Primero incrementamos a (a=2) y luego asignamos a c (c=2)
		System.out.println("Valor de c es: "+c+" Valor de a es: "+a);

		
//		SUFIJA a++ (primero asigna y luego incrementa)
		
//		int a = 1;
//		int c = a++;	//  Primero asignamos a c (c=1) y luego incrementamos a (a=2)
//	System.out.println("Valor de c es: "+c+" Valor de a es: "+a);


	}

}
