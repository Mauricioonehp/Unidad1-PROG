package ASIGNACIONES;



/*
 * Crear NOTA1 y NOTA2 con los valores 4 y 5.
 * Usando ++ y -- en forma prefija y sufija, transformar una nota en otra
 * y viceversa, y darles otros valores.
 * Después, hacer lo mismo pero solo con ++ y --.
 */
public class MASMAS_MENOSMENOS {

	public static void main(String[] args) {
		
		// ================= PARTE 1: PREFIJO Y SUFIJO EN ASIGNACIONES =================
        int NOTA1 = 4;
        int NOTA2 = 5;
        System.out.println("Inicio:                NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2); // 4, 5

        // SUFIJO: asigna el valor actual de NOTA2 (5) y DESPUÉS lo decrementa
        NOTA1 = NOTA2--;   // NOTA1 = 5, NOTA2 = 4  -> se han intercambiado
        System.out.println("NOTA1 = NOTA2--:       NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // SUFIJO: asigna el valor actual de NOTA2 (4) y DESPUÉS lo incrementa
        NOTA1 = NOTA2++;   // NOTA1 = 4, NOTA2 = 5  -> vuelven a los valores originales
        System.out.println("NOTA1 = NOTA2++:       NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // PREFIJO: PRIMERO decrementa NOTA2 (5 -> 4) y luego asigna
        NOTA1 = --NOTA2;   // NOTA2 = 4, NOTA1 = 4
        System.out.println("NOTA1 = --NOTA2:       NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // PREFIJO: PRIMERO incrementa NOTA1 (4 -> 5) y luego asigna
        NOTA2 = ++NOTA1;   // NOTA1 = 5, NOTA2 = 5
        System.out.println("NOTA2 = ++NOTA1:       NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // OTROS VALORES
        NOTA1 = ++NOTA2;   // NOTA2 = 6, NOTA1 = 6
        NOTA2 = NOTA1--;   // NOTA2 = 6, NOTA1 = 5
        System.out.println("Otros valores:         NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // ================= PARTE 2: SOLO ++ Y -- (SIN ASIGNACIONES) =================
        NOTA1 = 4;
        NOTA2 = 5;
        System.out.println("\nInicio:                NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2); // 4, 5

        // Transformar una nota en otra: 4 -> 5 y 5 -> 4
        NOTA1++;           // NOTA1 = 5
        NOTA2--;           // NOTA2 = 4
        System.out.println("Intercambiadas:        NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // Y viceversa: volver a 4 y 5
        --NOTA1;           // NOTA1 = 4
        ++NOTA2;           // NOTA2 = 5
        System.out.println("Vuelta al inicio:      NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);

        // OTROS VALORES
        ++NOTA1;
        ++NOTA1;           // NOTA1 = 6
        NOTA2--;
        NOTA2--;           // NOTA2 = 3
        System.out.println("Otros valores:         NOTA1 = " + NOTA1 + ", NOTA2 = " + NOTA2);
		
		
		
	}

}
