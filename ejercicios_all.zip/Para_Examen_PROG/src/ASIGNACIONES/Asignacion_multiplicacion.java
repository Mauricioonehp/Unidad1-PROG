package ASIGNACIONES;

import java.util.Scanner;
//
//Pedir un salario y un porcentaje de subida para actualizarlo con el operador *= y
//mostrarlo redondeado al entero más próximo.
public class Asignacion_multiplicacion {

	public static void main(String[] args) {
		
		
		
		 Scanner sc = new Scanner(System.in);

	        // ----- PEDIR LOS DATOS -----
	        System.out.println("Ingresa el salario");
	        double salario = sc.nextDouble();

	        System.out.println("Ingresa el porcentaje de subida");
	        double porcentaje = sc.nextDouble();

	        sc.close();

	        // ----- ACTUALIZAR EL SALARIO -----
	        // Una subida del 10% equivale a multiplicar por 1.10
	        // salario = salario * (1 + porcentaje / 100)
	        salario *= (1 + porcentaje / 100);

	        // ----- MOSTRAR REDONDEADO -----
	        // Math.round() redondea al entero más próximo (devuelve long)
	        System.out.println("El nuevo salario es: " + Math.round(salario));
	}

}
