package ASIGNACIONES;

public class Asiganaciones_Boleanos {
	/*
	 * 4º.- Resolver las siguientes operaciones booleanas indicando si son
	 *      True o False, si se cumple que a=1, b=2 y c=3.
	 *
	 * REGLAS BÁSICAS:
	 *   &&  (Y)  -> true solo si LAS DOS partes son true
	 *   ||  (O)  -> true si AL MENOS UNA parte es true
	 *   !   (NO) -> da la vuelta: !true = false  y  !false = true
	 *
	 * TRUCO: resolver de dentro hacia fuera (primero los paréntesis).
	 */
	public static void main(String[] args) {
		
		   int a = 1, b = 2, c = 3;
		   
		   
	        // Columna izquierda
		// 3 <= c && b > 1
	        // Sustituyo:  3 <= 3 && 2 > 1
	        // 3 <= 3 -> true
	        // 2 > 1  -> true
	        // true && true -> TRUE
	        System.out.println("3 <= c && b > 1: " + (3 <= c && b > 1));              // true
	        // 3 <= c && (!(b > 1))
	        // 3 <= 3 -> true
	        // b > 1 es 2 > 1 -> true
	        // !(true) -> false
	        // true && false -> FALSE
	        System.out.println("3 <= c && (!(b > 1)): " + (3 <= c && (!(b > 1))));    // false
	     // 3 <= c || b < 1
	        // 3 <= 3 -> true
	        // b < 1 es 2 < 1 -> false
	        // true || false -> TRUE (con || basta que una sea true)
	        System.out.println("3 <= c || b < 1: " + (3 <= c || b < 1));              // true
	        
	     // ===================== COLUMNA DERECHA =====================

	        // !(4 == c) && (2 == a)
	        // 4 == c es 4 == 3 -> false
	        // !(false) -> true
	        // 2 == a es 2 == 1 -> false
	        // true && false -> FALSE
	        // Columna derecha
	        System.out.println("!(4 == c) && (2 == a): " + (!(4 == c) && (2 == a)));  // false
	        // !(4 == c) && ((2 == c) || (a >= 1))
	        // !(4 == c) -> !(false) -> true
	        // 2 == c -> 2 == 3 -> false
	        // a >= 1 -> 1 >= 1 -> true
	        // (false || true) -> true
	        // true && true -> TRUE
	        
	        System.out.println("!(4 == c) && ((2 == c) || (a >= 1)): "
	        		
	                + (!(4 == c) && ((2 == c) || (a >= 1))));                         // true
	        // !(4 == c) && ((2 < (c-b)) || (a >= 1)) && (a + b) >= 2
	        // !(4 == c) -> true
	        // c-b = 3-2 = 1  ->  2 < 1 -> false
	        // a >= 1 -> true
	        // (false || true) -> true
	        // a + b = 3  ->  3 >= 2 -> true
	        // true && true && true -> TRUE
	        System.out.println("!(4 == c) && ((2 < (c-b)) || (a >= 1)) && (a + b) >= 2: "
	                + (!(4 == c) && ((2 < (c - b)) || (a >= 1)) && (a + b) >= 2));    // true
		
//	        System.out.println("si es verdad "+(3<=0 || b>1)); PRUEBA MIA
	        
	        
	}

}
