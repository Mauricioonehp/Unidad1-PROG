package ASIGNACIONES;

import java.util.Scanner;

/*
 * 2º.- Añadir al anterior la petición de una comisión y de otro porcentaje
 *      de subida/bajada para actualizarla con el operador *= al entero más próximo.
 *      Sumar el salario y la comisión y mostrarlos redondeados al entero inferior.
 */

public class Asignacion_COMISIONES {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);

	        // ----- PEDIR LOS DATOS DEL SALARIO -----
	        System.out.println("Ingresa el salario");
	        double salario = sc.nextDouble();

	        System.out.println("Ingresa el porcentaje de subida del salario");
	        double porcSalario = sc.nextDouble();

	        // ----- PEDIR LOS DATOS DE LA COMISIÓN -----
	        System.out.println("Ingresa la comisión");
	        double comision = sc.nextDouble();

	        System.out.println("Ingresa el porcentaje de subida/bajada de la comisión (negativo si baja)");
	        double porcComision = sc.nextDouble();

	        sc.close();

	        // ----- ACTUALIZAR CON *= -----
	        // Subida del 10% -> * 1.10 | Bajada del 10% (-10) -> * 0.90
	        salario *= (1 + porcSalario / 100);
	        comision *= (1 + porcComision / 100);

	        // ----- MOSTRAR AL ENTERO MÁS PRÓXIMO -----
	        System.out.println("Salario actualizado: " + Math.round(salario));
	        System.out.println("Comisión actualizada: " + Math.round(comision));

	        // ----- SUMAR Y MOSTRAR AL ENTERO INFERIOR -----
	        // Math.floor() redondea hacia abajo (devuelve double, por eso el cast a long)
	        double total = salario + comision;
	        System.out.println("Total (salario + comisión): " + (long) Math.floor(total));

	}

}
