package Ejercicios_primeraunidad;

import javax.swing.JOptionPane;

public class Menu_selecciones {
	
	
//	.- Mostrar al usuario un menú de elección, hecho con ShowOptionDialog, con la suma, resta,
//	multiplicación y división. Pedirle dos números y en función de su elección mostrarle la operación correspondiente.
	
	
	
	
	public static void main(String[] args) {

		 // ----- MENÚ CON 4 BOTONES -----
        // Devuelve la POSICIÓN del botón pulsado: 0, 1, 2, 3 (y -1 si cierra con la X)
        int opcion = JOptionPane.showOptionDialog(null, "Elige una operación", "Calculadora",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[] {"Suma", "Resta", "Multiplicación", "División"}, "Suma");
        
     // Si cierra la ventana con la X, terminamos el programa
        if (opcion == -1) {
            System.exit(0);
        }

        // ----- PEDIR LOS DOS NÚMEROS -----
        // showInputDialog devuelve un String; Double.parseDouble lo pasa a número
        double num1 = Double.parseDouble(JOptionPane.showInputDialog("Inserte el primer número"));
        double num2 = Double.parseDouble(JOptionPane.showInputDialog("Inserte el segundo número"));

        // ----- MOSTRAR LA OPERACIÓN ELEGIDA -----
        if (opcion == 0) {
            JOptionPane.showMessageDialog(null, "La suma es: " + (num1 + num2));

        } else if (opcion == 1) {
            JOptionPane.showMessageDialog(null, "La resta es: " + (num1 - num2));

        } else if (opcion == 2) {
            JOptionPane.showMessageDialog(null, "La multiplicación es: " + (num1 * num2));

        } else {
            // opcion == 3 -> División
            if (num2 == 0) {
                JOptionPane.showMessageDialog(null, "No se puede dividir entre 0");
            } else {
                JOptionPane.showMessageDialog(null, "La división es: " + (num1 / num2));
            }
	}

	}
}
