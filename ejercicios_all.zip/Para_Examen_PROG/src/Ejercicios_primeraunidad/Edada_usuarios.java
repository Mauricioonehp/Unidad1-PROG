package Ejercicios_primeraunidad;

import java.util.Scanner;

public class Edada_usuarios {
//	1º.- Pedir al usuario su edad y mostrar mensajes si acaba de cumplir los 18, si es mayor de edad
//	y si es menor de edad. Acotar las edades límites como cero y 100, si se salen de ellas mostrar mensajes.
//	Recuerda que en los IF la igualdad con números necesita un doble igual (==) para funcionar.
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Ingresa tu edad: ");
		double edad = sc.nextDouble();
		
		if (edad<0 || edad>100) {
			
			System.out.println("Ingresa un dato real ");
			main(null); //reinicia el programa de forma limpia 
		}
		
		else {
			// Evaluamos las 3 opciones dentro de tu estructura original
			if (edad>=18) {
				System.out.println("eres mayor de edad ");
			}
			else {
				System.out.println("eres menor de edad ");
			}
		}
		sc.close(); 		// El Scanner se cierra aquí, al puro final, para que no falle al reiniciar
	}

}
