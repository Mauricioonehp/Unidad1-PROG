package Ejercicio_MAIN;

import java.util.Scanner;

//Crear una app que reciba tres salarios y nos diga si existe alguno igual entre ellos. Opcional: averiguar
//cuántos son iguales.
public class Salarios {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("ingresa salario 1");
		int salario1 = sc.nextInt();
		
		System.out.println("ingresa salario 2");
		int salario2 = sc.nextInt();
		
		System.out.println("ingresa salario 3");
		int salario3 = sc.nextInt();
		sc.close();
		if (salario1 == salario2 && salario2 == salario3) {
            // Los tres son iguales
            System.out.println("Sí hay iguales: los 3 salarios son iguales");

        } else if (salario1 == salario2 || salario1 == salario3 || salario2 == salario3) {
            // Solo una pareja es igual
            System.out.println("Sí hay iguales: hay 2 salarios iguales");

        } else {
            // Ninguna pareja coincide
            System.out.println("No hay ningún salario igual");
        }
		
		
	}

}
