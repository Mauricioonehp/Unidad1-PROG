package Ejercicio_MAIN;

import java.util.Scanner;

//Calcular la edad del usuario usando el año actual y el año de su nacimiento sin tener en cuenta el mes y
//día.


public class Calcular_edad {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("cual es el año de tu nacimiento ");
		int nacimiento = sc.nextInt();
		System.out.println("Cual es el año actual?");
		int actual = sc.nextInt();
		
		
		int años = actual-nacimiento;
		sc.close();
		System.out.println("la edad de usted es de : "+años);
		
		//otro manera de hacerlo es : 
		// con solo 
//		if (nacimiento > actual) {
//		    System.out.println("El año de nacimiento no puede ser mayor que el actual");
//		} else {
//		    System.out.println("La edad de usted es de: " + (actual - nacimiento));
//		}
		
	}

}
