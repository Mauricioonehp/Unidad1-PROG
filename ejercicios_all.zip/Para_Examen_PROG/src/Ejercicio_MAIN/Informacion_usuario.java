package Ejercicio_MAIN;

import java.util.Scanner;

public class Informacion_usuario {
//	 Pedir al usuario que nos diga su Nombre, Apellido1, Apellido2, Altura (en metros), Edad y Sexo.
//	 Mostrarlo por pantalla con la siguiente salida por pantalla,
//	 Usted se llama A B C
//	 con una altura de D metros,
//	 una edad de E años
//	 y es F
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingresa tu nombre ");
		String nombre = sc.nextLine();
		System.out.println("Ingresa tu primer apellido ");
		String apellido1 = sc.nextLine();
		System.out.println("Ingresa tu  segundo apellido ");
		String apellido2 = sc.nextLine();
		
		System.out.println("Ingresa tu altura");
		double altura = sc.nextDouble();
		System.out.println("Ingresa tu edad");
		String edad = sc.next();
		System.out.println("Ingresa tu sexo");
		String sexo = sc.next();
		
		sc.close();
		System.out.println("usted se llama "+ nombre + apellido1 + apellido2 +
							"\nCon altura "+ altura +" metros , "+
							"\nY una edad de "+ edad +" años"+
							 "\nY es "+ sexo);
		
		
		
		
	}

}
