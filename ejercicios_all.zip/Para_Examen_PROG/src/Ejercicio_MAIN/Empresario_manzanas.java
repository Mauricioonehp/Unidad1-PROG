package Ejercicio_MAIN;

import java.util.Scanner;

//
//Un empresario necesita gestionar las ventas de las manzanas de su frutería. Para ello nos ha pedido que
//diseñemos una app que nos solicitará el precio de venta por kilo, en decimales, y las ventas en kilos
//enteros de cada trimestre. La app mostrará el importe anual.
public class Empresario_manzanas {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingresa la venta por kilo ");
		double precio = sc.nextDouble();
		  System.out.println("Kilos vendidos en el 1er trimestre");
	        int kilos1 = sc.nextInt();
	        System.out.println("Kilos vendidos en el 2º trimestre");
	        int kilos2 = sc.nextInt();
	        System.out.println("Kilos vendidos en el 3er trimestre");
	        int kilos3 = sc.nextInt();
	        System.out.println("Kilos vendidos en el 4º trimestre");
	        int kilos4 = sc.nextInt();

	        sc.close();
	        // Importe anual = precio * total de kilos del año

	        double importe = precio * (kilos1 + kilos2 + kilos3 + kilos4);
	        
	        System.out.println("el importe anual es de : "+importe+ " euros");
	}

}
