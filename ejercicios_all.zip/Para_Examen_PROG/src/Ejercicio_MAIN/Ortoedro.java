package Ejercicio_MAIN;

import java.util.Scanner;

//Crear una app que nos calcule el volumen de un ortoedro (rectángulo en 3D), nos pedirá los tres
//lados. se multiplican sus tres dimensiones: largo, ancho y alto
public class Ortoedro {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa Largo ");
		
		double largo = sc.nextDouble();
		
		System.out.println("Ingresa ancho ");
		
		double ancho = sc.nextDouble();
		
		System.out.println("Ingresa alto ");
		
		double alto = sc.nextDouble();
		sc.close();

		double volumen = largo*ancho*alto;
		
		System.out.println("El volumen del ortoedro es de : "+ volumen);
		
	}

}
