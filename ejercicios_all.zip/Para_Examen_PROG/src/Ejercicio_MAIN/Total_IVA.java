package Ejercicio_MAIN;

import java.util.Scanner;

/*
 * App que recibe la base imponible y el IVA a aplicar (en %)
 * y devuelve el total de ambas.
 */
public class Total_IVA {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingresa la base imponible");
        double base = sc.nextDouble();

        System.out.println("Ingresa el IVA a aplicar (en %)");
        double iva = sc.nextDouble();

        sc.close();

        // Importe del IVA: porcentaje de la base
        double importeIva = base * iva / 100;

        // Total = base + IVA
        double total = base + importeIva;

        System.out.println("El IVA es de: " + importeIva + " €");
        System.out.println("El total es de: " + total + " €");
    }
}