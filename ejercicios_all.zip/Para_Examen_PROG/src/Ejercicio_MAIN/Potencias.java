package Ejercicio_MAIN;

import java.util.Scanner;

public class Potencias {

//) Crearemos una app que calcule la potencia, para ello pediremos al usuario un número entero como base
//y otro entero como exponente.
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
//		double por int y nextDouble() por nextInt(), porque piden enteros.
		System.out.println("ingresa la base en entero ");
		int entero = sc.nextInt();
		System.out.println("ingresa otro entero para el exponente");
		int exponente = sc.nextInt();
		sc.close();
		
		 // Math.pow siempre devuelve double, así que se hace cast a long
        // para mostrarlo sin decimales (long aguanta resultados más grandes que int)
		
//		int potencia = Math.pow(entero, exponente); // tambien sirve pero sin redondear (long) delante de Math.pow(...), para que el resultado salga sin .0.
		long potencia = (long)Math.pow(entero, exponente);
		
		System.out.println("la potencia del numero es : "+potencia);
		
	}

}
