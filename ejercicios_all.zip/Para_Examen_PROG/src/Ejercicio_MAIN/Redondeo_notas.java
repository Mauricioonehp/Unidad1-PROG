package Ejercicio_MAIN;

import java.util.Scanner;

//Crear una app que reciba dos notas decimales y muestre la media de ambas pero redondeadas al entero más próximo.
public class Redondeo_notas {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("ingresa primera  nota exacta ");
		double nota1=sc.nextDouble();
		System.out.println("Ingresa segunda nota");
		double nota2=sc.nextDouble();
		sc.close();
		
		long notaf= Math.round(nota1/nota2);  // long es el mismo que el double ambos sirven 
		
		System.out.println("la nota final redondeada al mas proximo es : "+notaf);
	}

}
