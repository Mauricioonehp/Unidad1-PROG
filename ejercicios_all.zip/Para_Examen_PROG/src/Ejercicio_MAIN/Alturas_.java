package Ejercicio_MAIN;

import java.util.Scanner;
//3) Pedir al usuario su altura en metros y mostrarla en centímetros.
public class Alturas_ {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa tu altura en metros ");
		double metros = sc.nextDouble();
		
		double centimetros=metros*100;
		
		System.out.println("tu altura en centimetros es  "+(int)centimetros+"cm"); // castear para que salga un int 
		
		sc.close();
	}
	
	//ejemplo : int entero = 5;
//	double decimal = entero; // Java lo convierte a 5.0 automáticamente

}
