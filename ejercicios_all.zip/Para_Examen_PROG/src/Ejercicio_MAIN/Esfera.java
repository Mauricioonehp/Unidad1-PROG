package Ejercicio_MAIN;

import java.util.Scanner;

//Crear una app que calcule el volumen de una esfera con la fórmula V = 4/3 * PI * r3
//y mostrar el
//resultado en dos líneas con \n.
//	
public class Esfera {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa el radio ");
		double radio = sc.nextDouble();
		sc.close();
		
        // 4.0 / 3 para que la división conserve decimales

		double volumen = (4/3.0)* Math.PI*Math.pow(radio, 3);  // 4.0 es double -> el resultado es double -> 1.3333... , cuando son 2 enteros solo es 1
		
		System.out.println("El radio de la esfera es: " + radio + 
					"\nEl volumen de la esfera es: " + volumen);

	}

}
