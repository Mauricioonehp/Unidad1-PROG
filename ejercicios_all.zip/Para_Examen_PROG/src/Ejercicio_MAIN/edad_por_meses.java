package Ejercicio_MAIN;

import java.util.Scanner;


//1) Pedir al usuario que escriba su edad en meses y mostrar los años.

public class edad_por_meses {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("ingresa tu edad en meses");
		int meses = sc.nextInt();

		int edadF = meses / 12;
		sc.close();
		System.out.println("tu edad es de " + edadF);
		
		
//		2) Pedir al usuario que escriba su edad en años por teclado y mostrarla en meses.
//
//		Scanner sc = new Scanner(System.in);
//		System.out.println("ingresa tu edad  ");
//		int edad = sc.nextInt();
//		
//		int mesesF=edad*12;
//		sc.close();
//		System.out.println("tu edad es de "+mesesF);
//		
//		sc.close();
//
//		
	}

}
