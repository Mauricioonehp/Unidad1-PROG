package Ejercicio_MAIN;

import java.util.Scanner;

//Diseñar una app que calcule el área de un triángulo, sabiendo que es base por altura dividida entre
//dos. Nos tiene que pedir la base y la altura.

	
public class Triangulo {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa la base");
		double base= sc.nextDouble();
		System.out.println("Ingresa la altura");
		double altura = sc.nextDouble();
		sc.close();
		double area = base*altura/2;
		
		System.out.println("El area del triangulo es : "+area);
		
		
		
		
		
		
	}

}
