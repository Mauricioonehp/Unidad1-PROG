package SCANNERS;

import java.text.DecimalFormat;
import java.util.Scanner;

public class IMC_EJEMPLO {

//	3º.- Introducir por pantalla nuestra altura como decimal y el peso como entero y mostrar el IMC (Índice de Masa Corporal)
//	aplicando la fórmula IMC = Peso / (estatura * estatura). Valores adecuados son < 25.

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#.00");
		System.out.println("ingresa tu altura como decimal");

		double altura = sc.nextDouble();

		System.out.println("ingresa peso como entero");

		int peso = sc.nextInt();
		
		sc.close();

		double IMC = peso / (altura * altura);
		
		if (IMC < 25) {
			System.out.println("Tu IMC esta bien es de : " + IMC);
		} else {
			System.out.println("Tu IMC no es adecuado "+df.format(IMC)+"(debe ser menor a 25)");
		}
	}

}
