package SCANNERS;

import java.util.Scanner;

public class Ejemplos_sexo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);


		        System.out.println("Ingresa tu sexo");
		        String sexo = sc.next();

		        sc.close();
		        char inicial = sexo.charAt(0);//		        char inicial = Character.toUpperCase(sexo.charAt(0)); 
//		        Si quieres que la inicial salga siempre en mayúscula aunque el usuario escriba hombre, puedes usar:

		        System.out.println("tu sexo comienza por " + inicial);
		    

	
		
	}

}
