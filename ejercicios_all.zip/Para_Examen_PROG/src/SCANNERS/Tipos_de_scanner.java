package SCANNERS;

import java.util.Scanner;

public class Tipos_de_scanner {

	public static void main(String[] args) {
		
		
//        
//        Scanner sc = new Scanner(System.in); 		//Creamos el scanner entrada 
//        String nombre;					   	// Creamos una variable nombre
//        System.out.println("Introduzca su nombre :");
//        nombre = sc.next();		   		// Asignamos nombre a la lectura
//
//        System.out.println("El nombre es "+ nombre );  	// Lo comprobamos
//        sc.close();						// Cerramos la entrada de datos por teclado

//      String---------------nextLine() ó next() 
//    	int------------------nextInt()
//    	long-----------------nextLong()
//    	float----------------nextFloat()
//    	double---------------nextDouble()
//    	boolean--------------nextBoolean()	
        Scanner sc = new Scanner(System.in);
		System.out.print("Introduzca su nombre principal: ");
		String text = sc.next();	// Probar con nextLine
		System.out.println(text);
		sc.close();
		
	
		
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Introduzca su nombre principal: ");
//		char nb = sc.next().charAt(0);	//Solo admite char aunque la ayuda indique
//		System.out.println(nb);		// también String
//		ent.close();
//
////     
////
////        
//        
	}

}
