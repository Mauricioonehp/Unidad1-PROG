package SCANNERS;

import java.util.Scanner;

public class Ejercicio_PESO_IDEAL {
	 
//	2º.- Pedir por pantalla el peso del usuario como entero, transformarlo a 
//	decimal reduciéndolo en un 3 % y mostrarlo por pantalla como su peso ideal. 
	public static void main(String[] args) {
			
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa tu peso en entero");
		
		int peso=sc.nextInt();
		sc.close();
        // Conversión implícita a decimal y cálculo directo (100% - 3% = 97%)
		
//		double pesoi = pesod - (pesod * 0.15); otra manera
// o esto : double pesoIdeal = peso * 0.85;

		double pesoIdeal = peso * 0.97;
		
		System.out.println("Tu peso ideal es "+pesoIdeal+"kg");
		
	}

}
