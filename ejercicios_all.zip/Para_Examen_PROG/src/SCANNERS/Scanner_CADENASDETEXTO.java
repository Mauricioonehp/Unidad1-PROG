package SCANNERS;
	
import java.util.Scanner;

public class Scanner_CADENASDETEXTO {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduzca una cadena de texto con varias e: ");
		String cad = sc.nextLine();
		sc.close();
		char c='e';
		int contador=0;
		for(int i=0;i<cad.length();i++){
			if (cad.charAt(i)==c){
				contador++;
			}
		}
			System.out.println("La letra "+c+" aparece "+contador+" veces");

			
//		for (int i = 0; i < cad.length(); i++) {
//			
//		}
			
			
//			RECUERDA :
//				No se pueden separar por comas los objetos (entrada en el ejemplo) de Scanner, hay que escribirlas en líneas separadas, aunque sean del mismo tipo.
//				Indicando un solo new Scanner sirve para varias entradas
//				Es recomendable cerrar la captura de datos por teclado con <nombre variable>.close()

	}

}
