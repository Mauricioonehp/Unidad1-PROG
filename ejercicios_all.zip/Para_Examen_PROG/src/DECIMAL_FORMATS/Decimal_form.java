package DECIMAL_FORMATS;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Decimal_form {

	public static void main(String[] args) {
		//		static final int MAXCUENTA=100;	Variable estática constante numérica entera con operaciones
//		  final int maxcuenta=100; // ejemplo de final numero que no se puede mover
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un numero");
		double num = sc.nextDouble();
		sc.close();
		
		DecimalFormat df = new DecimalFormat("0	.00"); // redondea al mas cercano
		//ponemos comas a los miles y punto a los decimales
		
		System.out.println(df.format(num));   //debe ir dentro de la variable la variable 
		//damos formato a la variable num
		
//		Con poner una sola # sirve para todos los enteros que queramos, NO ASÍ CON LOS 0
//
//		El método format() devuelve un String, por lo que se puede usar como CONVERSOR A STRING
//
//		
	}

}
