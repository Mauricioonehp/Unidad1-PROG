/**
 * 
 */
/**
 * 
 */
module Para_Examen_PROG {
	requires java.desktop;
}