package Ejercicios_IF;
//1)	Pedir al usuario que introduzca dos notas decimales, mostrarle la nota media
//		redondeada al entero más próximo y decirle si ha aprobado o no. 

import javax.swing.JOptionPane;

public class Notas_rango {

	public static void main(String[] args) {
		
		double nota1=Double.parseDouble(JOptionPane.showInputDialog("ingresa primera nota "));
		double nota2=Double.parseDouble(JOptionPane.showInputDialog("ingresa segunda nota "));
        // Primero la media (dividir), después redondear

		int notaf = (int) Math.round((nota1 + nota2) / 2);
		
	
		
		
		if (nota1<0 || nota1>10 || nota2<0 || nota2>10) {
			JOptionPane.showMessageDialog(null, "NOTAS NO VALIDAS");
			main(null);
		}
		else {
			if (notaf>=5) {
				JOptionPane.showMessageDialog(null, "Estas aprobado");
			}
			else {
				JOptionPane.showMessageDialog(null, "Estas desaprobado");
			}
		}
		
	
	}

}
