package Ejercicios_IF;

import javax.swing.JOptionPane;

//3)	Calcular el IMC (índice de masa corporal) del usuario pidiendo el peso en kilos como entero y
//la altura como decimal en metros. Aplicar la fórmula IMC = peso / (altura*altura). Usar la Wikipedia para conocer los intervalos. 

/*
 * Calcular el IMC pidiendo el peso en kilos (entero) y la altura en metros (decimal).
 * IMC = peso / (altura * altura)
 * Intervalos (OMS):
 *   < 18.5       Bajo peso
 *   18.5 - 24.9  Peso normal
 *   25 - 29.9    Sobrepeso
 *   30 - 34.9    Obesidad grado I
 *   35 - 39.9    Obesidad grado II
 *   >= 40        Obesidad grado III (mórbida)
 */

public class Calcular_IMC {

	public static void main(String[] args) {
		
		
		// Peso como entero y altura como decimal
        int peso = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tu peso en kilos (entero)"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa tu altura en metros (decimal)"));

        // Fórmula del enunciado
        double imc = peso / (altura * altura);
     
        double imcRedondeado = Math.round(imc * 100) / 100.0;   // IMC con 2 decimales

        if (imc < 18.5) {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nBajo peso");

        } else if (imc < 25) {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nPeso normal");

        } else if (imc < 30) {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nSobrepeso");

        } else if (imc < 35) {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nObesidad grado I");

        } else if (imc < 40) {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nObesidad grado II");

        } else {
            JOptionPane.showMessageDialog(null, "Tu IMC es: " + imcRedondeado + "\nObesidad grado III (mórbida)");
        }
        
        
        

//        // Cada tramo muestra directamente su mensaje
//        if (imc < 18.5) {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nBajo peso");
//
//        } else if (imc < 25) {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nPeso normal");
//
//        } else if (imc < 30) {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nSobrepeso");
//
//        } else if (imc < 35) {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nObesidad grado I");
//
//        } else if (imc < 40) {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nObesidad grado II");
//
//        } else {
//            JOptionPane.showMessageDialog(null, "Tu IMC es " + imc + "\nObesidad grado III (mórbida)");
//        }
		
		

//		// Peso como entero y altura como decimal
//        int peso = Integer.parseInt(JOptionPane.showInputDialog("Ingresa tu peso en kilos (entero)"));
//        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingresa tu altura en metros (decimal)"));
//
//        // Fórmula del enunciado
//        double imc = peso / (altura * altura);
//
//        String clasificacion;
//
//        // De menor a mayor: usamos < con el límite superior de cada tramo,
//        // así no quedan huecos entre 24.9 y 25, por ejemplo
//        if (imc < 18.5) {
//            clasificacion = "Bajo peso";
//        } else if (imc < 25) {
//            clasificacion = "Peso normal";
//        } else if (imc < 30) {
//            clasificacion = "Sobrepeso";
//        } else if (imc < 35) {
//            clasificacion = "Obesidad grado I";
//        } else if (imc < 40) {
//            clasificacion = "Obesidad grado II";
//        } else {
//            clasificacion = "Obesidad grado III (mórbida)";
//        }
//
//        // Math.round(imc * 100) / 100.0 deja el IMC con 2 decimales
//        JOptionPane.showMessageDialog(null, "Tu IMC es: " + Math.round(imc * 100) / 100.0 + "\nClasificación: " + clasificacion);
//		
	}

}
