package Ejercicios_IF;

import javax.swing.JOptionPane;

//4)	Pedir al usuario el porcentaje de grasa y el porcentaje de agua. 
//
//	Si la grasa es superior a 40 hay riesgo de problemas cardíacos, si es menor no.
//	Si el agua es inferior a 20 hay riesgo de problemas cardíacos, si es mayor no.

public class Porcentaje_awa {

	public static void main(String[] args) {
	
		
		double grasa = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el porcentaje de grasa"));
        double agua = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el porcentaje de agua"));

        // Comprobación de la grasa (independiente de la del agua)
        if (grasa > 40) {
            JOptionPane.showMessageDialog(null, "Grasa: hay riesgo de problemas cardíacos");
        } else {
            JOptionPane.showMessageDialog(null, "Grasa: no hay riesgo de problemas cardíacos");
        }

        // Comprobación del agua
        if (agua < 20) {
            JOptionPane.showMessageDialog(null, "Agua: hay riesgo de problemas cardíacos");
        } else {
            JOptionPane.showMessageDialog(null, "Agua: no hay riesgo de problemas cardíacos");
        }
		

	}

}
