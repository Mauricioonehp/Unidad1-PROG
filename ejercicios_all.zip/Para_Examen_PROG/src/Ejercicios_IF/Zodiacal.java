package Ejercicios_IF;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

//Crear una app que calcule signo zodiacal mediante el mes posible de nacimiento de los bebés, para ello
//pedir el número de mes y mostrarle la predicción, 
public class Zodiacal {

	public static void main(String[] args)throws IOException {
		int mes = Integer.parseInt(JOptionPane.showInputDialog("Inserte el número del mes"));
		String prediccion = "Sagitario o Capricornio";
		if (mes < 1 || mes > 12) {
		JOptionPane.showMessageDialog(null, "Mes no válido");
	
		} else {
		if (mes == 1) {
		prediccion = "Acuario o Capricornio";
		} else if (mes == 2) {
		prediccion = "Acuario o Piscis";
		} else if (mes == 3) {
		prediccion = "Piscis u Aries";
		} else if (mes == 4) {
		prediccion = "Aries o Tauro";
		} else if (mes == 5) {
		prediccion = "Tauro o Géminis";
		} else if (mes == 6) {
		prediccion = "Géminis o Cáncer";
		} else if (mes == 7) {
		prediccion = "Cáncer o Leo";
		} else if (mes == 8) {
		prediccion = "Leo o Virgo";
		} else if (mes == 9) {
		prediccion = "Virgo o Libra";
		} else if (mes == 10) {
		prediccion = "Libra u Escorpio";
		} else if (mes == 11) {
		prediccion = "Escorpio o Sagitario";
		}
		}
		// Escritura del archivo HTML con la tabla del horóscopo
		PrintWriter pw = new PrintWriter(new FileWriter("Horoscopo.html", false));
		
		pw.println("<html><head><title>Predicción del Horóscopo</title></head>");
		pw.println("<body><h1><center>Predicción del horóscopo</center></h1>");
		pw.println("<center><table border='1' style='text-align: center'>");
		pw.println("<tr style='background-color: #fff2f2'>");
		pw.println("<th>SIGNOS PREDICCIÓN</th><th>MES INSERTADO</th>");
		pw.println("</tr>");
		pw.println("<tr><td>"+prediccion+"</td><td>"+mes+"</td></tr>");
		pw.println("</table></center><br></body></html>");
		pw.flush();
		pw.close();
		File path = new File("Horoscopo.html");
		Desktop.getDesktop().open(path);

	}

}
