package Ejercicios_IF;

import javax.swing.JOptionPane;
/*
 * Pedir dos notas decimales, mostrar la nota media redondeada al entero
 * más próximo y decir si ha sacado sobresaliente, notable, bien,
 * suficiente o insuficiente.
 */
public class Sobresalientes_etc {

	  public static void main(String[] args) {
		  
		  
		  double nota1 =Double.parseDouble(JOptionPane.showInputDialog("Inserte la nota 1"));
		  double nota2 =Double.parseDouble(JOptionPane.showInputDialog("Inserte la nota 2"));
		  double media = Math.round((nota1+nota2)/2);
		  
			if (media < 1 || media > 10) {
				JOptionPane.showMessageDialog(null, "Nota no válida");
			} else {
				if (media < 5) {
					JOptionPane.showMessageDialog(null, "IS");
				} else if (media < 6) {
					JOptionPane.showMessageDialog(null, "SF");
				} else if (media < 7) {
					JOptionPane.showMessageDialog(null, "BI");
				} else if (media < 9) {
					JOptionPane.showMessageDialog(null, "NT");
				} else if (media < 10) {
					JOptionPane.showMessageDialog(null, "SB");
				} else if (media == 10) {
					JOptionPane.showMessageDialog(null, "MH");
				}
			}
//
//	        double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa primera nota"));
//	        double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa segunda nota"));
//
//	        // Validamos que las notas estén entre 0 y 10
//	        if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
//	            JOptionPane.showMessageDialog(null, "NOTAS NO VÁLIDAS");
//	            main(null);   // Volvemos a pedir las notas
//	            return;       // Evita seguir con los datos incorrectos al terminar la repetición
//	        }
//
//	        // Primero la media (sumar y dividir), después redondear
//	        int media = (int) Math.round((nota1 + nota2) / 2);
//
//	        String calificacion;
//
//	        if (media >= 9) {
//	            calificacion = "Sobresaliente";      // 9 - 10
//	        } else if (media >= 7) {
//	            calificacion = "Notable";            // 7 - 8
//	        } else if (media == 6) {
//	            calificacion = "Bien";               // 6
//	        } else if (media == 5) {
//	            calificacion = "Suficiente";         // 5
//	        } else {
//	            calificacion = "Insuficiente";       // 0 - 4
//	        }
//
//	        JOptionPane.showMessageDialog(null, "Nota media: " + media + "\nCalificación: " + calificacion);
	    }
		
	}

