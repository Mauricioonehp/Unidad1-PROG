package Equeals;

import java.util.Scanner;

public class Ejercicio_Trivial {

	public static void main(String[] args) {
		
		
		
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Como se llama nuestro IDE");
	        // Pedimos la respuesta al usuario

			String ide= sc.nextLine();// nextLine() lee la línea completa
			
			sc.close();
	        // equalsIgnoreCase() compara dos Strings IGNORANDO mayúsculas y minúsculas

			if (ide.equalsIgnoreCase("java")) {
				System.out.println("es correcto");
			}
			else {
				System.out.println("No es correcto sigue intentando ");
			}
			
	}

}
