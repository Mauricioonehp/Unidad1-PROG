package Equeals;

import java.util.Scanner;

public class Equeal_cadenas_texto {


		public static void main(String[] args) {
			Scanner sc= new Scanner(System.in);
			System.out.println("Escriba la cadena 1:  ");
			String cad1=sc.nextLine();
					
			System.out.println("Escriba la cadena 2: ");
			String cad2=sc.nextLine();
			sc.close();
			if (cad1.equals(cad2)) 
				System.out.println("Las dos cadenas son iguales");
			else	
				
				System.out.println("Las dos cadenas son distintas");
		}

		
		
	}


