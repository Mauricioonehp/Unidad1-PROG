package Equeals;

public class Metodo_equals {

	
	public static void main(String[] args) {
//		String cad1="Sancho";
//		String cad2="Sancho";
//		System.out.println(cad1.equals(cad2));
		
		
		String cad1="Sancho";
		String cad2="sancho";					// Cambiamos la S a s
		System.out.println(cad1.equalsIgnoreCase(cad2));		// Ponemos EIC

	}
}



