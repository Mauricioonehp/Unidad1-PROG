package Sumas;

import java.util.Scanner;

public class Sumas_Scanners {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Ingresa un numero:");
		
		int a =sc.nextInt();
		System.out.println("Ingresa numero");
		int b =sc.nextInt();
		System.out.println("Ingresa numero");
		int c = sc.nextInt();
		
		sc.close();
		
		int X=a+b+c;
		
		System.out.println("la suma de los 3 numeros es :"+X);
		
	}

}
