package Sumas;

import java.util.Scanner;
		/*1º.- Pedir tres números al usuario y mostrar por pantalla con literales la suma de los tres, la multiplicación de los tres y
		luego la suma de los dos primeros divididos por el tercero. Usar los paréntesis para calcular los datos en la salida por pantalla.*/



public class Multis {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingresa num");
		double a=sc.nextDouble();
		System.out.println("Ingresa num");
		double b=sc.nextDouble();
		System.out.println("Ingresa num");
		double c=sc.nextDouble();
		sc.close();
		
//		double sum= a+b+c;
//		double mult=a*b*c;
//		double div=a+b/c;
		

        // Suma de los dos primeros dividida por el tercero.
        // Los paréntesis de (a + b) son necesarios para que la suma
        // se haga ANTES que la división.
		System.out.println("LA SUMA DE LOS 3 NUMEROS ES "+(a+b+c)+"\nLa Multiplicacion de los 3 numeros es :"+(a*b*c)+"\nLa suma de los 2 y divididos :"+((a+b)/c));
		
		
	}

}
