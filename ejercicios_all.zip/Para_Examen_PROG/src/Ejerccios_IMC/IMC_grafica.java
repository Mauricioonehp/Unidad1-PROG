package Ejerccios_IMC;

import javax.swing.JOptionPane;

public class IMC_grafica {

	public static void main(String[] args) {

		        double base = 535400;

		        double bai = Math.round(base * 1.21);
		        double bdi = Math.round(bai * 0.70);

		        double totalFundadores = Math.round(bdi * 0.70);
		        double cadaFundador = Math.round(totalFundadores / 2);

		        double totalOtros = Math.round(bdi * 0.30);
		        double cadaOtro = Math.round(totalOtros / 3);

		        // \n salta de línea dentro de la ventana
		        JOptionPane.showMessageDialog(null,
		                "El BAI es de : " + bai + " €"
		                + "\nEl BDI es de : " + bdi + " €"
		                + "\nEl BDI para los socios fundadores es de : " + totalFundadores + " €"
		                + "\nEl BDI para cada uno de los dos socios fundadores es de : " + cadaFundador + " €"
		                + "\nEl BDI para los socios es de : " + totalOtros + " €"
		                + "\nEl BDI para cada uno de los tres socios es de : " + cadaOtro + " €");
		    }
		}
	
