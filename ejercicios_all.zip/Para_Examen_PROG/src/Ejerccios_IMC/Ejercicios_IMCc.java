package Ejerccios_IMC;

public class Ejercicios_IMCc {

	public static void main(String[] args) {


		        double base = 535400;

		        // 1) BAI: base + 21% de IVA
		        double bai = Math.round(base * 1.21);

		        // 2) BDI: BAI menos el 30% de impuestos (queda el 70%)
		        double bdi = Math.round(bai * 0.70);

		        // 3) Socios fundadores: 70% del BDI, y son 2
		        double totalFundadores = Math.round(bdi * 0.70);
		        double cadaFundador = Math.round(totalFundadores / 2);

		        // 4) Otros socios: 30% del BDI, y son 3
		        double totalOtros = Math.round(bdi * 0.30);
		        double cadaOtro = Math.round(totalOtros / 3);

		        System.out.println("El BAI es de : " + bai + " €");
		        System.out.println("El BDI es de : " + bdi + " €");
		        System.out.println("El BDI para los socios fundadores es de :" + totalFundadores + " €");
		        System.out.println("El BDI para cada uno de los dos socios fundadores es de :" + cadaFundador + " €");
		        System.out.println("El BDI para los socios es de :" + totalOtros + " €");
		        System.out.println("El BDI para cada uno de los tres socios es de :" + cadaOtro + " €");
		    }
		}
	


