package Ejerccios_IMC;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class Bloc_notas_IMC {

	public static void main(String[] args) throws IOException {		// ----- PEDIR LA BASE IMPONIBLE (forma gráfica) -----
        // showInputDialog devuelve un String; Double.parseDouble lo pasa a número
//        double base = Double.parseDouble(JOptionPane.showInputDialog("Inserte la base imponible", "535400"));
        double base = 535400; // por defecto

        // ----- BAI: base + 21% de IVA (multiplicar por 1.21) -----
        double bai = Math.round(base * 1.21);

        // ----- BDI: BAI menos 30% de impuestos (queda el 70%) -----
        double bdi = Math.round(bai * 0.70);

        // ----- SOCIOS FUNDADORES: son 2 y acumulan el 70% del BDI -----
        double totalFundadores = Math.round(bdi * 0.70);
        double cadaFundador = Math.round(totalFundadores / 2);

        // ----- OTROS SOCIOS: son 3 y acumulan el 30% del BDI -----
        double totalOtros = Math.round(bdi * 0.30);
        double cadaOtro = Math.round(totalOtros / 3);

        // ----- TEXTO CON TODOS LOS RESULTADOS -----
        // \n = salto de línea (sirve en la ventana y en el archivo)
        String resultado = "El BAI es de : " + bai + " €"
                + "\nEl BDI es de : " + bdi + " €"
                + "\nEl BDI para los socios fundadores es de : " + totalFundadores + " €"
                + "\nEl BDI para cada uno de los dos socios fundadores es de : " + cadaFundador + " €"
                + "\nEl BDI para los socios es de : " + totalOtros + " €"
                + "\nEl BDI para cada uno de los tres socios es de : " + cadaOtro + " €";

        // ----- MOSTRAR EN VENTANA -----
        JOptionPane.showMessageDialog(null, resultado);

        // ----- ESCRIBIR EN UN ARCHIVO -----
        // false = sobrescribe si ya existía (true añadiría al final)
        FileWriter fw = new FileWriter("D:/socios.txt", false);
        fw.write(resultado);
        fw.flush();   // vuelca lo pendiente al archivo
        fw.close();   // cierra el archivo

        // ----- ABRIRLO CON EL BLOC DE NOTAS -----
        Desktop.getDesktop().open(new File("D:/socios.txt"));

	}

}
