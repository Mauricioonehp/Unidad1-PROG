package JOPTIONS;

import javax.swing.JOptionPane;

public class ShowOptiondialog {

	public static void main(String[] args) {
		int seleccion = JOptionPane.showOptionDialog(null, "Ejemplo dialogo Option", "Info", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Si", "No","Cancelar"}, "Si"); 
//		int seleccio = 	JOptionPane.showOptionDialog(null, "Ejemplo", "Info",JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,null, new Object[] {"si", "no", "luego"}, "Aceptar");
	
	// ESTO ES PARA PERSONALIZAR TUS BOTONES
	
		if (seleccion == 0) {
		    JOptionPane.showMessageDialog(null, "Has pulsado Sí");
		} else if (seleccion == 1) {
		    JOptionPane.showMessageDialog(null, "Has pulsado No");
		} else {
		    JOptionPane.showMessageDialog(null, "Has cancelado");
		}
	}

}
