package JOPTIONS;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Iconesss {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "Icono", "Icono", JOptionPane.INFORMATION_MESSAGE,
				new ImageIcon(Iconesss.class.getResource("/JOPTIONS/compu.gif"))); // ruta del packete donde esta mejor antes de importarlo desde una carpte mas complicado o solo tambien puede ser  compu.gif

			
//		int seleccion = JOptionPane.showOptionDialog(null, 
//    			"¿Te gusta mi app?", "Pregunta", 
//    			JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, 
//    			null, new Object[] {"Siiiii", "Nooooo","Cancelar"}, "Siiiii");
//    	if (seleccion==0){
//    			JOptionPane.showMessageDialog(null, "Muchas gracias", "Gracias", 					JOptionPane.INFORMATION_MESSAGE);
//	}
//    	else if (seleccion==1){
//    		JOptionPane.showMessageDialog(null, "Seguiré mejorando", "Gracias", 					JOptionPane.ERROR_MESSAGE);
//	}
//    	else {
//		JOptionPane.showMessageDialog(null, "ns/nc", "Gracias", 						JOptionPane.INFORMATION_MESSAGE);
//	}

	}

		
	}

