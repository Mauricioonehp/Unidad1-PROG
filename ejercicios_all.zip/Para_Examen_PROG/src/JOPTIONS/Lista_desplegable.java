package JOPTIONS;

import javax.swing.JOptionPane;

public class Lista_desplegable {

	public static void main(String[] args) {
//		Object color = JOptionPane.showInputDialog(null, "Seleccione Un Color", "COLORES", JOptionPane.QUESTION_MESSAGE,
//				null, new Object[] { "Seleccione", "Amarillo", "Azul", "Rojo" }, "Seleccione");
//	
//		if (color.equals("Amarillo")) {
//			JOptionPane.showMessageDialog(null, "Ha seleccionado amarillo");
//		} else if (color.equals("Azul")) {
//			JOptionPane.showMessageDialog(null, "Ha seleccionado azul");
//		} else if (color.equals("Rojo")) {
//			JOptionPane.showMessageDialog(null, "Ha seleccionado rojo");
//		} else {
//			System.exit(0);
//		}
		
		Object numeros =JOptionPane.showInputDialog(null,"selecciona un numero,","numeros ",JOptionPane.QUESTION_MESSAGE,
				null,new Object[] {"1","2","3"},"seleccione");
		
		if (numeros.equals("1")) {
			JOptionPane.showMessageDialog(null, "Ha seleccionado 1");
		} else if (numeros.equals("2")) {
			JOptionPane.showMessageDialog(null, "Ha seleccionado 2 ");
		} else if (numeros.equals("3")) {
			JOptionPane.showMessageDialog(null, "Ha seleccionado 3");
		} else {
			System.exit(0);
		}
		

	}

}
