package JOPTIONS;

import javax.swing.JOptionPane;

public class InputDialog {

	public static void main(String[] args) {

////		Pero debemos saber que esta clase recibe los valores como String, por lo que, si vamos a pedir número, deberemos realizar
////		una conversión para poder usarlos con Integer.parseInt y Double.parseDouble. Por ejemplo,
//		String nume =JOptionPane.showInputDialog(null, "Mensaje" , "Info", JOptionPane.INFORMATION_MESSAGE);
//		
//		int numero = Integer.parseInt(JOptionPane.showInputDialog ("Escribe un numero"));
//
//		double numer1 =Double.parseDouble(JOptionPane.showInputDialog("ESCRIBE OTRO NUMERO"));
////		Si no es así, lo podremos guardar en una variable del tipo String para luego poder trabajar con ella. 
//
//		JOptionPane.showMessageDialog(null,"el numero ingresado es  "+nume+"aaaa"+numero+"adada "+numer1);

	
		String nombre=JOptionPane.showInputDialog(null, "Introduce tu nombre" 	);
        
//	       JOptionPane.showMessageDialog(null, "El nombre introducido es "+nombre, "Mensaje", 	JOptionPane.QUESTION_MESSAGE);  ambas maneras sirven sin el quisto message
	       
	       JOptionPane.showMessageDialog(null, "tu nombre es "+nombre);
	    }

	
	
	
	
	}

