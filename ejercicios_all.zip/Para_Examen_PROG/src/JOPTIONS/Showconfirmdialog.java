package JOPTIONS;

import javax.swing.JOptionPane;

public class Showconfirmdialog {

	public static void main(String[] args) {

//		int seleccion = JOptionPane.showConfirmDialog(null, "Ejemplo dialogo Option", "Info", JOptionPane.YES_NO_CANCEL_OPTION );
// EJEMPLO 
		
		
		
		int seleccion = JOptionPane.showConfirmDialog(null,
				"¿Te gusta mi App?", "Info", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, null);

		if (seleccion == 0) { // SI
			JOptionPane.showMessageDialog(null, "Gracias");
		} 
else if (seleccion == 1) { // NO
			JOptionPane.showMessageDialog(null, "La mejoraré");
		} 
else { // Cancelar
			JOptionPane.showMessageDialog(null, "Adios");
		}

	}

}
