package JOPTIONS;

import javax.swing.JOptionPane;

public class MessageDialog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "mensaje" , "Info", JOptionPane.INFORMATION_MESSAGE);
//		                               1       2          3               4

//		1.- El componente padre, si ponemos this como una referencia a sí mismo, se bloqueará mientras esté abierto el cuadro de mensaje, 
//		impidiendo que se efectúen otras acciones, en cambio sí le pasamos null estará disponible para otras acciones. También se le puede poner el componente gráfico y el mensaje se verá dentro de él.
//
//		2.- Cuerpo del mensaje: es el texto a mostrar, permite cadenas, variables, expresiones, etc.
//
//		3.- Título del cuadro: es el title del cuadro. 
//
//		4.- Tipo de mensaje: es uno de los cinco tipos siguientes de mensajes de la clase, 

		
//		JOptionPane.showInternalMessageDialog(null, "holaaa");
		
		
		int precioProducto=300;
        final double IVA=0.21;
 
    JOptionPane.showMessageDialog(null, "El precio incluido el IVA es "+(precioProducto+(precioProducto*IVA))	, "Mensaje", JOptionPane.INFORMATION_MESSAGE);   
   }

	}


