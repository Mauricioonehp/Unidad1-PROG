package ejercicios;

import java.util.Scanner;

public class Ortoedro {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("vamos a sacar el volumen de Ortoedro");
		System.out.println("Ingresa el largo");
		double largo = sc.nextDouble();
		System.out.println("ingresa el ancho");
		double ancho = sc.nextDouble();
		System.out.println("ingresa el alto");
		double alto = sc.nextDouble();

		double volumen = largo * ancho * alto;

		System.out.println("el volumen del Ortoedro es: " + volumen);

		sc.close();

	}

}
