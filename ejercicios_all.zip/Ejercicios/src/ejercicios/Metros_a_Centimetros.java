package ejercicios;

import java.util.Scanner;

public class Metros_a_Centimetros {

	public static void main(String[] args) {

		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("dime tu altura en metros:");
		
		double altura=sc.nextDouble();
		
		
		System.out.println("tu altura en centimetros es :"+altura*100+"cm");
		
		
		
		sc.close();
		
		
		
		
		
		
	}

}
