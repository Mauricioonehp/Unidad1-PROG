package ejercicios;

import java.util.Scanner;

public class Meses_a_años {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("ingresa tu edad en meses: ");
		int meses = sc.nextInt();

		System.out.println("tu tienes: " + meses / 12 + " años");

		// 252 años = 21

		sc.close();
	}

}
