package ejercicios;

import java.util.Scanner;

public class Convertir_a_entero {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		
		System.out.println("ingresa tu primera nota: ");
		double nota1=sc.nextDouble();
		System.out.println("ingresa tu segunda nota: ");
		double nota2=sc.nextDouble();
		
		
		int nota3=(int) Math.round(nota1+nota2);
		
		
		
		System.out.println("tu promedio final es : "+nota3);
		
		
		
		
		
		
		sc.close();
		
		
		
		
	}

}
