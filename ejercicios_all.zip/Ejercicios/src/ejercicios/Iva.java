package ejercicios;

import java.util.Scanner;

public class Iva {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("dame la base para sacar su iva");
		double base = sc.nextDouble();

		double iva =base* 1.21;

		System.out.println("el monto total con iva es " + iva+" €");

		sc.close();

	}

}
