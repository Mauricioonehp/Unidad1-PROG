package ejercicios;

import java.util.Scanner;

public class Info_de_usuarios {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
				 	
		System.out.println("ingrese su nombre: ");
		String nombre = sc.next();
		System.out.println("Ingrese su primer apellido: ");
		String apellido1=sc.next();
		System.out.println("Ingrese su segundo apellido: ");
		String apellido2=sc.next();
		System.out.println("Ingresa tu altura:");
		double altura=sc.nextDouble();
		System.out.println("Ingrese su edad: ");
		int edad=sc.nextInt();
		System.out.println("¿eres masculino o femenino?");
		String sexo=sc.next();
		System.out.println("Usted se llama "+ nombre+" "+ apellido1 +" " + apellido2 );		
		System.out.println("con una altura de "+altura+" metros");
		System.out.println("una edad de "+ edad +" edad");
		System.out.println("y es "+sexo);
	sc.close();
	}
	
}
