package ejercicios;

import java.util.Scanner;

public class Esfera {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("ingrese el radio");
		double dato = sc.nextDouble();
		double volumen = (4.0 / 3.0) * Math.PI * Math.pow(dato, 3);

		System.out.println("el volumen de la esfera es: " + volumen);

		sc.close();

	}

}
