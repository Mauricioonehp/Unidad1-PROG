package ejercicios;

import java.util.Scanner;

public class Manzanitas {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("dame el precio de venta por kilos");
		double kilos = sc.nextDouble();
		System.out.println("Ahora las ventas en kilos de cada trimestre");
		double ventas = sc.nextDouble();

		double importe = kilos * ventas / 3;

		System.out.println("Tu importe anual es :" + importe);

		sc.close();

	}

}
