package ejercicios;

import java.util.Scanner;

public class Años_a_meses {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("ingresa tu edad: ");
		int años=sc.nextInt();
		
		
		
		System.out.println("tu edad en meses es :"+años*12);
		
		
		
		
		
		// 21 = 252 en meses
		
		
		
		
		
		
		
		
		sc.close();
	}

}
