package ejercicios;

import java.util.Scanner;

public class App_de_salarios {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Ingrese salario 1: ");
		int salario1 = sc.nextInt();
		System.out.println("Ingrese salario2: ");
		int salario2 = sc.nextInt();
		System.out.println("Ingrese salario3: ");
		int salario3 = sc.nextInt();
		int contador = 0;
//		boolean uno_dos = (salario1 == salario2);
//		boolean uno_tres = (salario1 == salario3);
//		boolean tres_dos = (salario3 == salario2);
//
//		boolean hayiguales = uno_dos || uno_tres || tres_dos;
//
//		if (uno_dos && uno_tres && tres_dos) {
//			System.out.println("los tres salarios son iguales 1 , 2, 3");
//		} else if (hayiguales) {
//			System.out.println("Hay salarios iguales.");
//			if (uno_dos) {
//				System.out.println("El salario 1 y el salario 2 son iguales (" + salario1 + ")");
//			}
//			if (uno_tres) {
//				System.out.println("El salario 1 y el salario 3 son iguales (" + salario1 + ")");
//			}
//			if (tres_dos) {
//				System.out.println("El salario 2 y el salario 3 son iguales (" + salario2 + ")");
//			}
//		} else {
//			System.out.println("No hay salarios iguales entre ellos.");
//		}
//

		if (salario1 == salario2) {
			contador++;
		}
		if (salario1 == salario3) {
			contador++;
		}
		if (salario2 == salario3) {
			contador++;
		}

		System.out.println("el salario " + contador + " que se repite  " + contador + " vez");

		sc.close();
//		
//		
//		
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

		
		
		
		
		

		
	
}
