package ejercicios;

import java.util.Scanner;

public class Potencias {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		
		System.out.println("ingresa  un numero entero para la base");
		int num1 = sc.nextInt();
		System.out.println("ingresa un numero para el exponente");
		int num2 = sc.nextInt();
		
		int num3= Math.powExact(num1, num2);
		 
		System.out.println("la potencia del segundo numero es: "+num3);
		
		
		sc.close();
	}

}
