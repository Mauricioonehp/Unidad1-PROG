package ejercicios;

import java.util.Scanner;

public class area {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("ingresa la base");
		double base = sc.nextDouble();
		System.out.println("ingresa la altura");
		double altura = sc.nextDouble();

		double area = base * altura / 2;

		System.out.println("el area del triangulo es: " + area);

		sc.close();

	}

}
