package ejercicios;

import java.util.Scanner;

public class Nacimiento_a_años {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("dime tu año de nacimiento");
		int año_nacimiento = sc.nextInt();
		int año_actual = java.time.Year.now().getValue();
		int edad = año_actual - año_nacimiento;

		System.out.println("tu edad aprox es: " + edad + "años");

		sc.close();
	}
}
